import ui
import os
import psutil
import globals
import time
import func

import ttkbootstrap as ttk
import tkinter as tk

from PIL import Image, ImageTk
from ttkbootstrap.dialogs.dialogs import Messagebox
from ttkbootstrap.dialogs.dialogs import Querybox
from ttkbootstrap.tooltip import ToolTip
from ttkbootstrap.constants import *

import ctypes
from ctypes import wintypes

# load configurations
def load_transparency_file():
    try:
        file_path = "C:\\Zero Software\\ZeroFiles\\res\\transparency.txt"
        
        with open(file_path, "r") as file:
            content = file.read().strip()
        
        transparency = float(content)
        return transparency
    except Exception as e:
        print(f"Error loading file: {e}")
        return None

# Load the transparency value
transparency = load_transparency_file()
if transparency is not None:
    pass
else:
    transparency = 100  # Default value if loading fails

def load_config(path, default_value, cast_func=str):
    try:
        with open(path, "r") as file:
            content = file.read().strip().lower()  # Converting content to lowercase

            # Handle bool conversion explicitly with both truthy and falsy values
            if cast_func == bool:
                if content in ['true', '1', 'yes']:
                    return True
                elif content in ['false', '0', 'no']:
                    return False
                else:
                    return default_value  # If the content doesn't match expected values, return default

            # For other types, just cast it
            return cast_func(content)
    except Exception as e:
        print(f"Error loading file: {e}")
        return default_value

# File paths
paths = {
    "topmostConfig": "C:\\Zero Software\\ZeroFiles\\res\\window\\topmost.txt",
}

# Load values with defaults
topmost = load_config(paths["topmostConfig"], False, bool)

print(topmost)
import subprocess

def open_snake_game():
    subprocess.Popen(["C:\\Windows\\System32\\cmd.exe"])

def terminal():
    os.startfile(r"cmd.exe")

# create window
def createWindow():
    # root = tk.Tk()
    root = ttk.Window(themename=globals.theme)

    root.title(" ")
    root.geometry("1280x760")
    root.attributes("-alpha", transparency)
    root.attributes("-topmost", topmost)
    root.minsize(900, 450)


    root.resizable(True, True)
    root.iconbitmap("C:\\Zero Software\\ZeroFiles\\icon.ico")

    # keybinds

    root.bind('<Control-Alt-z>', lambda e: open_snake_game())
    root.bind('<Control-c>', lambda e: func.copy())
    root.bind('<Control-v>', lambda e: func.paste())
    root.bind('<Delete>', lambda e: ui.del_file_popup())
    root.bind('<Control-r>', lambda e: ui.rename_popup())
    root.bind('<Control-n>', lambda e: ui.new_file_popup())
    root.bind('<Control-Alt-n>', lambda e: ui.new_dir_popup())
    root.bind('<Alt-Left>', lambda e: func.previous())
    root.bind('<Alt-Right>', lambda e: func.next())
    root.bind('<F5>', lambda e: ui.refresh())
    return root

# configuration

    



def taboff():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\config\window\tablet\taboff.pyw")

def tabon():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\config\window\tablet\tabon.pyw")
    
def set1tp():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\config\tp\set1tp.pyw")

def set095tp():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\config\tp\set095tp.pyw")

def set092tp():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\config\tp\set092tp.pyw")

def setPS():
    os.startfile(r"C:\\Zero Software\\ZeroFiles\\comp\\config\\terminal\\setTerminalPS.pyw")

def setCMD():
    os.startfile(r"C:\\Zero Software\\ZeroFiles\\comp\\config\\terminal\\setTerminalCMD.pyw")

def onedrive():
    os.startfile(r"shell:OneDrive")
    
def docs():
    os.startfile(r"shell:personal")

def downloads():
    os.startfile(r"shell:downloads")

def music():
    os.startfile(r"shell:My music")

def video():
    os.startfile(r"shell:My videos")
def appwiz():
    os.startfile(r"C:\Windows\System32\appwiz.cpl")

def firewall():
    os.startfile(r"C:\Windows\System32\firewall.cpl")

def diskmgr():
    os.startfile(r"C:\Windows\System32\diskmgmt.msc")
def osl():
    os.startfile(r"Open Source Licenses.txt")
def personalise():
    os.startfile(r"ms-settings:personalisation")

def mmc():
    os.startfile(r"mmc.exe")
    


def stwin():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\userwindow.pyw")

def adwin():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\adminwindow.pyw")

def setKBFileSize():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\config\configs\units\setKB.pyw")

def setMBFileSize():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\config\configs\units\setMB.pyw")

def apps():
    os.startfile(r"shell:appsfolder")


# define popup dialogs

def osl_popup():  # popup window
    Messagebox.ok(
        message="Copyright 2024 Zero Software. Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.",
        title="Zero Files OSL (MIT)"
    )

def osl2_popup():  # popup window
    Messagebox.ok(
        message="2. Figtree Sans (font used by Zero Files):\nOriginal Creator: Erik D. Kennedy\nLicensed under the Open Font License. Learn more at https://openfontlicense.org/",
        title="Figtree Sans OSL (OFL)"
    )

def key_popup():  # popup window
    Messagebox.ok(
        message="SHORTCUTS\nFile Operations\nCtrl+C - Copy\nCtrl+V - Paste\nCtrl+R - Rename\nDel - Delete\nF5 - Refresh\n\nCreate\nCtrl+N - New File\nCtrl+Alt+N - New Directory\n\nOpen\nCtrl+O - Open File/Directory\nCtrl+Alt+O - Open In Terminal\n\nNavigation\nAlt+Left Arrow - Go Back\nAlt+Right Arrow - Go Forwards\nCtrl+Alt+Z - Unknown",
        title="Keyboard Shortcuts"
    )
    
def prop_popup():  # popup window
    Messagebox.ok(
        message="The file has been selected and you can right click\nchoose an option or enter properties.",
        title="Advanced Properties"
    )

def od_popup():  # popup window
    Messagebox.ok(
        message="The OneDrive Backup feature (BETA) lets you upload a file to your OneDrive account. Please meet the following prerequisites:\n1. Microsoft Account: Must be linked to your system.\n2. Privacy Disclosure Agreement: Agree to the following terms.\n\n### Privacy Disclosure\nBy using this feature, you agree to:\n1. Terms of Service: Microsoft’s TOS can be found here: https://www.microsoft.com/en-us/servicesagreement.\n2. File Handling: Your file will be copied to shell:onedrive and processed by Microsoft directly.\n3. No Access by Zero: Zero does not review or store your files; they go straight to OneDrive.\n4. Acknowledgment: You agree to these terms and the handling by Microsoft.\n5. Support: Contact our support team at zero.software@outlook.com for questions.",
        title="About OneDrive Backup"
    )

# System menu


def draw_usage_bar(canvas, used_percent):
    canvas.create_rectangle(0, 0, used_percent * 2, 20, fill="#F1F1F1")  # Width is multiplied by 2 for better visibility

def drive_stats(window):
    top = ttk.Toplevel(window)
    top.resizable(False, False)
    top.title("Drive Statistics")

    for drive in globals.available_drives:
        usage = psutil.disk_usage(drive)
        total_gb = round(usage.total / (1024 * 1024 * 1024), 2)  # Convert to GB with 2 decimal places
        used_gb = round(usage.used / (1024 * 1024 * 1024), 2)    # Convert to GB with 2 decimal places
        free_gb = round(usage.free / (1024 * 1024 * 1024), 2)    # Convert to GB with 2 decimal places
        percent_used = round(usage.percent, 2)

        frame = ttk.Frame(top)
        frame.pack(padx=10, pady=10, fill=tk.X)

        label_drive = ttk.Label(frame, text=f"Drive: {drive}")
        label_drive.pack(anchor=tk.W)

        label_total = ttk.Label(frame, text=f"Total: {total_gb} GB")
        label_total.pack(anchor=tk.W)

        label_used = ttk.Label(frame, text=f"Used: {used_gb} GB")
        label_used.pack(anchor=tk.W)

        label_free = ttk.Label(frame, text=f"Free: {free_gb} GB")
        label_free.pack(anchor=tk.W)

        label_percent = ttk.Label(frame, text=f"Usage: {percent_used}%")
        label_percent.pack(anchor=tk.W)

        # Canvas for usage bar
        canvas = tk.Canvas(frame, width=200, height=25)
        canvas.pack(anchor=tk.W)
        draw_usage_bar(canvas, percent_used)

        # Meter showing disk usage
        meter = ttk.Meter(
            frame,
            orient="horizontal",
            mode="determinate",
            maximum=total_gb,
            value=used_gb,
            length=200,
            thickness=20,
        )
        meter.pack(fill=tk.X)

    top.geometry(f"{len(globals.available_drives) * 220}x400")  # Adjusted height for better display

def cpu_stats():
    cpu_count_log = psutil.cpu_count()
    cpu_count = psutil.cpu_count(logical=False)
    cpu_per = psutil.cpu_percent()
    cpu_freq = round(psutil.cpu_freq().current / 1000, 2)
    Messagebox.ok(
        message="Usage: "
        + str(cpu_per)
        + "%"
        + "\nLogical Processors: "
        + str(cpu_count)
        + "\nCores: "
        + str(cpu_count_log)
        + "\nFrequency: "
        + str(cpu_freq)
        + " GHz",
        title="CPU",
    )


def memory_stats():
    memory_per = psutil.virtual_memory().percent
    memory_total = round(psutil.virtual_memory().total / (1024 * 1024 * 1024), 2)
    memory_used = round(psutil.virtual_memory().used / (1024 * 1024 * 1024), 2)
    memory_avail = round(psutil.virtual_memory().available / (1024 * 1024 * 1024), 2)
    Messagebox.ok(
        message="Usage: "
        + str(memory_per)
        + "%"
        + "\nTotal: "
        + str(memory_total)
        + " GB"
        + "\nUsed: "
        + str(memory_used)
        + " GB"
        + "\nAvailable: "
        + str(memory_avail)
        + " GB",
        title="Memory",
    )


def network_stats():
    net = psutil.net_io_counters(pernic=True)
    mes = ""
    for key, value in net.items():
        mes += (
            str(key)
            + ":\n"
            + "Sent: "
            + str(round(value.bytes_sent / (1024 * 1024 * 1024), 2))
            + " GB\n"
            + "Received: "
            + str(round(value.bytes_recv / (1024 * 1024 * 1024), 2))
            + " GB\n"
        )
    Messagebox.ok(message=mes, title="Network")


def processes_win():
    os.startfile(r"taskmgr")

# plugins
def obt():
    os.startfile(r"C:\Zero Software\ZeroUtil\fileorganise.pyw")

def tsk():
    os.startfile(r"C:\Zero Software\Zero Office\taskvwr.pyw")

def note():
    os.startfile(r"C:\Zero Software\Zero Office\notevwr.pyw")

def ppl():
    os.startfile(r"C:\Zero Software\Zero Office\people.pyw")

def password():
    os.startfile(r"C:\Zero Software\ZeroUtil\password.pyw")

def font_warning():
    # Create the messagebox with Yes/No buttons
    result = Messagebox.show_question(
        title="Font Style",
        message="Changing the font requires a restart. Continue?",
        buttons=['Yes', 'No']
    )

    if result == 'Yes':
        tfCustom()
    else:
        print("Aborted")
        return
        
# set typefaces
def tfInter():
    ui.warning_popup()
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\config\typeface\set_typeface\setTfInter.pyw")
    ui.restart_shell()

def tfCGothic():
    ui.warning_popup()
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\config\typeface\set_typeface\setTfCenturyGothic.pyw")
    ui.restart_shell()

def tfVerdana():
    ui.warning_popup()
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\config\typeface\set_typeface\setTfVerdana.pyw")
    ui.restart_shell()

def tfConsolas():
    ui.warning_popup()
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\config\typeface\set_typeface\setTfConsolas.pyw")
    ui.restart_shell()

def tfCustom():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\config\typeface\set_typeface\setTfCustom.pyw")
    ui.quit_program()

def dfDMY():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\config\configs\date_format\setDDMMYYYY.pyw")

def dfMDY():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\config\configs\date_format\setMMDDYYYY.pyw")

def dfYMD():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\config\configs\date_format\setYYYYMMDD.pyw")

# tablet mode menu
def tbm_menu():
    tbtoggle = Messagebox.show_question(
        title="Tablet Mode",
        message="Tablet Mode increases the size of items making them easier to tap. ",
        image=r"C:\Zero Software\ZeroFiles\icons\light\Folder-icon.png",
        buttons=['Enable', 'Disable', 'Cancel']
    )

    if tbtoggle == 'Enable':
        tabon()
    elif tbtoggle == 'Disable':
        taboff()
    elif tbtoggle == 'Cancel':
        return

def tasksHd():
    os.startfile(r"C:\Zero Software\Zero Office\taskvwr.pyw")

def powershell():
    os.startfile(r"C:\Windows\System32\WindowsPowerShell\v1.0\Powershell.exe")


# toolbars
def system():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\toolbars\system\toolbar.pyw")

def macros():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\toolbars\tasks\toolbar.pyw")

def tools():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\toolbars\tools\toolbar.pyw")

def view():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\toolbars\view\toolbar.pyw")

# toolbarsFalse
def systemF():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\toolbars\system\toolbarFalse.pyw")

def macrosF():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\toolbars\tasks\toolbarFalse.pyw")

def toolsF():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\toolbars\tools\toolbarFalse.pyw")

def viewF():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\toolbars\view\toolbarFalse.pyw")

# quickAccess
def admin():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\quickaccess\admin\toolbar.pyw")

def create():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\quickaccess\create\toolbar.pyw")

def edit():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\quickaccess\editFileWith\toolbar.pyw")

def explorer():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\quickaccess\explorer\toolbar.pyw")

def fileOperation():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\quickaccess\fileOperation\toolbar.pyw")

def search():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\quickaccess\search\toolbar.pyw")

def settings():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\quickaccess\settings\toolbar.pyw")

# quickAccessFalse
def adminF():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\quickaccess\admin\toolbarFalse.pyw")

def createF():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\quickaccess\create\toolbarFalse.pyw")

def editF():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\quickaccess\editFileWith\toolbarFalse.pyw")

def explorerF():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\quickaccess\explorer\toolbarFalse.pyw")

def fileOperationF():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\quickaccess\fileOperation\toolbarFalse.pyw")

def searchF():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\quickaccess\search\toolbarFalse.pyw")

def settingsF():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\quickaccess\settings\toolbarFalse.pyw")

def about_popup():  # popup window
    Messagebox.ok(
        message="Zero Files 2025 (Public Beta)\nVersion 25.1.1\nOpen Source Licenses: FilePilot (MIT License)",
        title="About",
    )

# accent colours
def primary():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\accents\BSp.pyw")

def secondary():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\accents\BSsc.pyw")

def success():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\accents\BSs.pyw")

def info():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\accents\BSi.pyw")

def danger():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\accents\BSd.pyw")

def warning():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\accents\BSw.pyw")

def light():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\accents\BSli.pyw")

def dark():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\accents\BSdk.pyw")


def topMostOn():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\config\window\topmost\tmon.pyw")

def topMostOff():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\config\window\topmost\tmoff.pyw")

# dock
def setDockTop():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\quickaccess\positionTop.pyw")

def setDockBottom():
    os.startfile(r"C:\Zero Software\ZeroFiles\comp\quickaccess\positionBottom.pyw")