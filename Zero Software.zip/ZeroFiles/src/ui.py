import tkinter as tk, os, subprocess,  psutil, ttkbootstrap as ttk, win32com.client, globals, func, ext, util, settings, theme_handler; from datetime import datetime; from functools import partial; from tkinter import filedialog; from PIL import Image, ImageTk, ImageColor; from ttkbootstrap.constants import *; from ttkbootstrap.dialogs.dialogs import Messagebox, Querybox; from ttkbootstrap.tooltip import ToolTip

def managePins():
    os.startfile("C:\\Zero Software\\pins.pyw")

def load_files():
    # Path to the directory
    directory = "C:\\Zero Software\\Macros"
    
    files = []
    # Walk through the directory
    for root, dirs, filenames in os.walk(directory):
        for filename in filenames:
            # Check if the file is a .py or .pyw file
            if filename.endswith('.py') or filename.endswith('.pyw'):
                # Create a relative path to flatten the structure
                relative_path = os.path.relpath(os.path.join(root, filename), directory)
                files.append(relative_path)
    
    # Sort files alphabetically
    files.sort()
    
    return files
    
    # Sort files alphabetically
    files.sort()
    
    return files

def on_file_select(filename):
    # Path to the file
    file_path = os.path.join("C:\\Zero Software\\Macros", filename)
    
    # Open the file with the default application
    if os.name == 'nt':  # For Windows
        os.startfile(file_path)
    elif os.name == 'posix':  # For Unix-based systems
        subprocess.call(('xdg-open', file_path))

def start_settings():
    os.startfile("C:\\Zero Software\\ZeroFiles\\src\\settings_menu.pyw")

import os

def load_file(path, default_value, cast_func=str):
    try:
        with open(path, "r") as file:
            return cast_func(file.read().strip())
    except Exception as e:
        print(f"Error loading file: {e}")
        return default_value

# File paths
paths = {
    "fileSizeUnit": "C:\\Zero Software\\ZeroFiles\\res\\config\\units\\fileSizeUnits.txt",
    "tvdense": "C:\\Zero Software\\ZeroFiles\\res\\window\\tvdensity.txt",
    "terminalType": "C:\\Zero Software\\ZeroFiles\\res\\config\\terminal\\terminal.txt",
    "fontstyle": r"C:\Zero Software\ZeroFiles\res\typeface.txt",
    "dateFormat": r"C:\Zero Software\ZeroFiles\res\config\view\dateformat.txt",
    "accent": r"C:\Zero Software\ZeroFiles\res\accent.txt",
    "quickAccessBarPos": r"C:\Zero Software\ZeroFiles\res\quickaccess\position.txt",
}

# Load values with defaults
fileSizeUnit = load_file(paths["fileSizeUnit"], 1024, int)
tvdense = load_file(paths["tvdense"], 40, int)
terminalType = load_file(paths["terminalType"], "util.terminal")
fontstyle = load_file(paths["fontstyle"], "Inter")
dateFormat = load_file(paths["dateFormat"], "%d/%m/%Y %H:%M")
accent = load_file(paths["accent"], "none")
quickAccessBarPos = load_file(paths["quickAccessBarPos"], "tk.BOTTOM")
print(accent)

# Set fileSizeUnitText
fileSizeUnitText = "MB" if fileSizeUnit == 1024 else "KB"

def load_toolbar(path, default_value, cast_func=str):
    try:
        with open(path, "r") as file:
            content = file.read().strip().lower()  # Converting content to lowercase

            # Handle bool conversion explicitly with both truthy and falsy values
            if cast_func == bool:
                if content in ['true', '1', 'yes']:
                    return True
                elif content in ['false', '0', 'no']:
                    return False
                else:
                    return default_value  # If the content doesn't match expected values, return default

            # For other types, just cast it
            return cast_func(content)
    except Exception as e:
        print(f"Error loading file: {e}")
        return default_value

# File paths
paths = {

    "sysToolbar": "C:\\Zero Software\\ZeroFiles\\res\\toolbars\\system\\toolbar.txt",
    "macToolbar": "C:\\Zero Software\\ZeroFiles\\res\\toolbars\\tasks\\toolbar.txt",
    "toolsToolbar": "C:\\Zero Software\\ZeroFiles\\res\\toolbars\\tools\\toolbar.txt",
    "vwToolbar": "C:\\Zero Software\\ZeroFiles\\res\\toolbars\\view\\toolbar.txt",
}

# Load values with defaults

sysToolEnabled = load_toolbar(paths["sysToolbar"], False, bool)
macToolEnabled = load_toolbar(paths["macToolbar"], False, bool)
viewToolEnabled = load_toolbar(paths["vwToolbar"], False, bool)
toolToolEnabled = load_toolbar(paths["toolsToolbar"], False, bool)

def load_quickaccess(path, default_value, cast_func=str):
    try:
        with open(path, "r") as file:
            content = file.read().strip().lower()  # Converting content to lowercase

            # Handle bool conversion explicitly with both truthy and falsy values
            if cast_func == bool:
                if content in ['true', '1', 'yes']:
                    return True
                elif content in ['false', '0', 'no']:
                    return False
                else:
                    return default_value  # If the content doesn't match expected values, return default

            # For other types, just cast it
            return cast_func(content)
    except Exception as e:
        print(f"Error loading file: {e}")
        return default_value

# File paths
paths = {
    "create": "C:\\Zero Software\\ZeroFiles\\res\\quickaccess\\create\\button.txt",
    "explorer": "C:\\Zero Software\\ZeroFiles\\res\\quickaccess\\explorer\\button.txt",
    "fileOp": "C:\\Zero Software\\ZeroFiles\\res\\quickaccess\\fileOperation\\button.txt",
    "settings": "C:\\Zero Software\\ZeroFiles\\res\\quickaccess\\settings\\button.txt",
    "admin": "C:\\Zero Software\\ZeroFiles\\res\\quickaccess\\admin\\button.txt",
    "edit": "C:\\Zero Software\\ZeroFiles\\res\\quickaccess\\edit\\button.txt",
}

# Load values with defaults
createEnabled = load_quickaccess(paths["create"], False, bool)
explorerEnabled = load_quickaccess(paths["explorer"], False, bool)
fileOpEnabled = load_quickaccess(paths["fileOp"], False, bool)
settingsEnabled = load_quickaccess(paths["settings"], False, bool)
adminEnabled = load_quickaccess(paths["admin"], False, bool)
editWithEnabled = load_quickaccess(paths["edit"], False, bool)

def start_terminal():
    if terminalType == "util.powershell":
        util.powershell()
    elif terminalType == "util.terminal":
        util.terminal()


def refresh(queryNames=None):
    globals.cwdLabel.delete(0, "end")
    globals.cwdLabel.insert(0, os.getcwd())

    fileSizesSum = 0

    if queryNames:
        globals.fileNames = queryNames
    else:
        globals.fileNames = []
        for item in os.listdir(os.getcwd()):
            full_path = os.path.join(os.getcwd(), item)
            if os.path.isfile(full_path) or os.path.isdir(full_path):
                globals.fileNames.append(full_path)

        # Sort globals.fileNames: folders first, then files
        globals.fileNames.sort(key=lambda x: (not os.path.isdir(x), x.lower()))

    fileSizes = [""] * len(globals.fileNames)
    fileDateModified = [""] * len(globals.fileNames)
    fileDateCreated = [""] * len(globals.fileNames)
    fileTypes = [""] * len(globals.fileNames)  # List to store file types

    for i in globals.items.get_children():
        globals.items.delete(i)

    for i, filename in enumerate(globals.fileNames):
        try:
            if os.path.isdir(filename):
                fileTypes[i] = "Directory"
                fileSizes[i] = ""
            else:
                # Importing get_file_type from ext module
                from ext import get_file_type
                fileTypes[i] = get_file_type(filename)
                fileSizes[i] = f"{os.stat(filename).st_size / 1024 / fileSizeUnit:.2f}".rstrip('0').rstrip('.') + fileSizeUnitText

            fileDateCreated[i] = datetime.fromtimestamp(os.path.getctime(filename)).strftime(dateFormat)
            fileDateModified[i] = datetime.fromtimestamp(os.path.getmtime(filename)).strftime(dateFormat)

            display_name = os.path.basename(filename)

            if fileTypes[i] == "Directory":
                globals.items.insert(parent="", index="end", values=(display_name, fileDateModified[i], fileTypes[i], ""), image=globals.folderIcon[0])
            else:
                if fileTypes[i] == "Document":
                    globals.items.insert(parent="", index="end", values=(display_name, fileDateModified[i], fileTypes[i], fileSizes[i]), image=globals.docIcon[0])
                elif fileTypes[i] == "Image":
                    globals.items.insert(parent="", index="end", values=(display_name, fileDateModified[i],fileTypes[i], fileSizes[i]), image=globals.photoIcon[0])
                elif fileTypes[i] == "Video":
                    globals.items.insert(parent="", index="end", values=(display_name, fileDateModified[i],fileTypes[i], fileSizes[i]), image=globals.videoIcon[0])
                elif fileTypes[i] == "Audio":
                    globals.items.insert(parent="", index="end", values=(display_name, fileDateModified[i],fileTypes[i], fileSizes[i]), image=globals.audioIcon[0])
                elif fileTypes[i] == "Application":
                    globals.items.insert(parent="", index="end", values=(display_name, fileDateModified[i],fileTypes[i], fileSizes[i]), image=globals.exeIcon[0])
                elif fileTypes[i] == "System":
                    globals.items.insert(parent="", index="end", values=(display_name, fileDateModified[i],fileTypes[i], fileSizes[i]), image=globals.systemIcon[0])
                elif fileTypes[i] == "Font":
                    globals.items.insert(parent="", index="end", values=(display_name, fileDateModified[i],fileTypes[i], fileSizes[i]), image=globals.fontFileIcon[0])
                elif fileTypes[i] == "ZIP Archive":
                    globals.items.insert(parent="", index="end", values=(display_name, fileDateModified[i],fileTypes[i], fileSizes[i]), image=globals.zipIcon[0])
                else:
                    globals.items.insert(parent="", index="end", values=(display_name, fileDateModified[i],fileTypes[i], fileSizes[i]), image=globals.fileIcon[0])

            fileSizesSum += int(fileSizes[i].split()[0])
            
        except Exception as e:
            pass

    globals.items.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

def fileInfo(queryNames=None):
    
    #global items
    iid = globals.items.focus()
    # iid = items.identify_row(event.y) # old
    if iid == "":  # if double click on blank, don't do anything
        return
    for item in globals.items.selection():
        tempDictionary = globals.items.item(item)
        tempName = tempDictionary["values"][0]  # get first value of dictionary
    try:
        newName = tempName
        filePath = os.getcwd() + "/" + tempName
        fileSize = f"{os.stat(filePath).st_size / 1024 / fileSizeUnit:.2f}".rstrip('0').rstrip('.') + fileSizeUnitText
        fileDateM = datetime.fromtimestamp(os.path.getmtime(tempName)).strftime(dateFormat)
        fileDateA = datetime.fromtimestamp(os.path.getatime(tempName)).strftime(dateFormat)
        fileDateC = datetime.fromtimestamp(os.path.getctime(tempName)).strftime(dateFormat)
        fileDir = os.path.dirname(filePath)
        from ext import get_file_type
        fileType = get_file_type(filePath)
        _, extension = os.path.splitext(filePath)

    except Exception as e:
        
        refresh([])

    Messagebox.ok(
        title="File Info",
        message="Name: " + newName + "\nFile Path: " + filePath + "\nParent: " + fileDir + "\nSize: " + fileSize + "\nType: " + fileType + "\nExtension: " + extension + "\nDate Accessed: " + fileDateA + "\nDate Modified: " + fileDateM + "\nDate Created: " + fileDateC
    )

def pinToSide(queryNames=None):
    
    #global items
    iid = globals.items.focus()
    # iid = items.identify_row(event.y) # old
    if iid == "":  # if double click on blank, don't do anything
        return
    for item in globals.items.selection():
        tempDictionary = globals.items.item(item)
        tempName = tempDictionary["values"][0]  # get first value of dictionary
    try:
        newName = tempName
        filePath = os.getcwd() + "/" + tempName
        func.add_pin(tempName, filePath)

    except Exception as e:
        
        refresh([])

def getPath():
    current_text = globals.cwdLabel.cget("text")

    os.system(f'echo {current_text.strip()} | clip')

    Messagebox.ok(
        title="Copied Path",
        message="Path copied to clipboard",
    )

def getFilePath():
    try:
        for item in globals.items.selection():
            tempDictionary = globals.items.item(item)
            tempName = tempDictionary["values"][0]  # get first value of dictionary

        filePathName = os.getcwd() + "/" + tempName

        os.system(f'echo {filePathName.strip()} | clip')

        Messagebox.ok(
            title="Copied Path",
            message="File Path copied to clipboard",
        )
    except Exception as e:
        Messagebox.ok(
            title="Cannot Copy Path",
            message="Please select a file or directory and try again.",
        )

import subprocess

def openInExplorer():
    try:
        selected_items = globals.items.selection()
        
        if not selected_items:
            print("No item selected.")
            return

        for item in selected_items:
            tempDictionary = globals.items.item(item)
            tempName = tempDictionary["values"][0]  # get first value of dictionary

            filePathName = os.path.join(os.getcwd(), tempName)

            # Using subprocess to call explorer with the `/select` option to highlight the file
            subprocess.run(['explorer', '/select,', os.path.normpath(filePathName)])

    except Exception as e:
        print(f"Error: {e}")

def openAdminMode():
    os.startfile("C:\\Zero Software\\ZeroFiles\\Zero (Admin).lnk")

def open_file_propertieshandler():
    try:
        for item in globals.items.selection():
            tempDictionary = globals.items.item(item)
            tempName = tempDictionary["values"][0]  # get first value of dictionary

        filePathName = os.getcwd() + "/" + tempName

        open_properties(filePathName)

    except Exception as e:
        Messagebox.ok(title="Error", message=e)

def open_properties(path):
    if not os.path.exists(path):
        raise ValueError("The specified path does not exist.")

    shell = win32com.client.Dispatch("Shell.Application")
    
    # Get the folder or file object
    folder = shell.Namespace(os.path.dirname(path))
    item = folder.ParseName(os.path.basename(path))
    
    if item is None:
        raise ValueError("Could not find the item.")

    # Open the properties window
    item.InvokeVerb("properties")


def create_widgets(window):
    s = ttk.Style()

    
    bootstyle = accent

    
    # Browse Frame
    browseFrame = ttk.Frame(window)
    scroll = ttk.Scrollbar(browseFrame, orient="vertical")
    globals.items = ttk.Treeview(
        browseFrame,
        columns=("Name", "Date modified","Type", "Size"),
        yscrollcommand=scroll.set,
        height=15,
        style="Custom.Treeview",
    )
    scroll.config(command=globals.items.yview)  # scroll with mouse drag
    # --Browse Frame

    # Setup icons
    if (globals.theme_mode == "mLight") or (globals.theme_mode == "light"):
        # File Type Icons
        globals.folderIcon = [tk.PhotoImage(file=globals.file_path + "light/Folder-icon.png"), "light/Folder-icon.png"]
        globals.fileIcon = [tk.PhotoImage(file=globals.file_path + "light/File-icon.png"), "light/File-icon.png"]
        globals.docIcon = [tk.PhotoImage(file=globals.file_path + "light/FileTypes/document.png"), "light/FileTypes/document.png"]
        globals.photoIcon = [tk.PhotoImage(file=globals.file_path + "light/FileTypes/photo.png"), "light/FileTypes/photo.png"]
        globals.videoIcon = [tk.PhotoImage(file=globals.file_path + "light/FileTypes/video.png"), "light/FileTypes/video.png"]
        globals.audioIcon = [tk.PhotoImage(file=globals.file_path + "light/FileTypes/audio.png"), "light/FileTypes/audio.png"]
        globals.exeIcon = [tk.PhotoImage(file=globals.file_path + "light/FileTypes/app.png"), "light/FileTypes/app.png"]
        globals.systemIcon = [tk.PhotoImage(file=globals.file_path + "light/FileTypes/system.png"), "light/FileTypes/system.png"]
        globals.fontFileIcon = [tk.PhotoImage(file=globals.file_path + "light/FileTypes/font.png"), "light/FileTypes/font.png"]
        globals.zipIcon = [tk.PhotoImage(file=globals.file_path + "light/FileTypes/zip.png"), "light/FileTypes/zip.png"]

        # UI Icons
        globals.backIcon = [tk.PhotoImage(file=globals.file_path + "light/back.png"), "light/back.png"]
        globals.frontIcon = [tk.PhotoImage(file=globals.file_path + "light/front.png"), "light/front.png"]
        globals.copyIcon = [tk.PhotoImage(file=globals.file_path + "light/copy.png"), "light/copy.png"]
        globals.cpuIcon = [tk.PhotoImage(file=globals.file_path + "light/cpu.png"), "light/cpu.png"]
        globals.deleteIcon = [tk.PhotoImage(file=globals.file_path + "light/delete.png"), "light/delete.png"]
        globals.driveIcon = [tk.PhotoImage(file=globals.file_path + "light/drive.png"), "light/drive.png"]
        globals.fontIcon = [tk.PhotoImage(file=globals.file_path + "light/font.png"), "light/font.png"]
        globals.appIcon = [tk.PhotoImage(file=globals.file_path + "light/app.png"), "light/window.png"]
        globals.infoIcon = [tk.PhotoImage(file=globals.file_path + "light/info.png"), "light/info.png"]
        globals.memoryIcon = [tk.PhotoImage(file=globals.file_path + "light/memory.png"), "light/memory.png"]
        globals.networkIcon = [tk.PhotoImage(file=globals.file_path + "light/network.png"), "light/network.png"]
        globals.pasteIcon = [tk.PhotoImage(file=globals.file_path + "light/paste.png"), "light/paste.png"]
        globals.pieIcon = [tk.PhotoImage(file=globals.file_path + "light/pie.png"), "light/pie.png"]
        globals.processIcon = [tk.PhotoImage(file=globals.file_path + "light/process.png"), "light/process.png"]
        globals.reloadIcon = [tk.PhotoImage(file=globals.file_path + "light/reload.png"), "light/reload.png"]
        globals.renameIcon = [tk.PhotoImage(file=globals.file_path + "light/rename.png"), "light/rename.png"]
        globals.scaleIcon = [tk.PhotoImage(file=globals.file_path + "light/scale.png"), "light/scale.png"]
        globals.themesIcon = [tk.PhotoImage(file=globals.file_path + "light/themes.png"), "light/themes.png"]
        globals.exitIcon = [tk.PhotoImage(file=globals.file_path + "light/exit.png"), "light/exit.png"]
        globals.gdriveIcon = [tk.PhotoImage(file=globals.file_path + "light/gdrive.png"), "light/gdrive.png"]
        globals.configIcon = [tk.PhotoImage(file=globals.file_path + "light/settings.png"), "light/settings.png"]
        globals.keybindIcon = [tk.PhotoImage(file=globals.file_path + "light/keyboard.png"), "light/keyboard.png"]
        globals.windowIcon = [tk.PhotoImage(file=globals.file_path + "light/window.png"), "light/window.png"]
        globals.winconfigIcon = [tk.PhotoImage(file=globals.file_path + "light/winconfig.png"), "light/winconfig.png"]
        globals.userIcon = [tk.PhotoImage(file=globals.file_path + "light/user.png"), "light/user.png"]
        globals.opacityIcon = [tk.PhotoImage(file=globals.file_path + "light/opacity.png"), "light/opacity.png"]
        globals.tabIcon = [tk.PhotoImage(file=globals.file_path + "light/tablet.png"), "light/tablet.png"]
        globals.dfIcon = [tk.PhotoImage(file=globals.file_path + "light/df.png"), "light/df.png"]
        globals.onedrvIcon = [tk.PhotoImage(file=globals.file_path + "light/onedrive.png"), "light/onedrive.png"]


    else:
        # File type icons
        globals.folderIcon = [tk.PhotoImage(file=globals.file_path + "dark/Folder-icon.png"), "dark/Folder-icon.png"]
        globals.fileIcon = [tk.PhotoImage(file=globals.file_path + "dark/File-icon.png"), "dark/File-icon.png"]
        globals.docIcon = [tk.PhotoImage(file=globals.file_path + "dark/FileTypes/document.png"), "dark/FileTypes/document.png"]
        globals.photoIcon = [tk.PhotoImage(file=globals.file_path + "dark/FileTypes/photo.png"), "dark/FileTypes/photo.png"]
        globals.videoIcon = [tk.PhotoImage(file=globals.file_path + "dark/FileTypes/video.png"), "dark/FileTypes/video.png"]
        globals.audioIcon = [tk.PhotoImage(file=globals.file_path + "dark/FileTypes/audio.png"), "dark/FileTypes/audio.png"]
        globals.exeIcon = [tk.PhotoImage(file=globals.file_path + "dark/FileTypes/app.png"), "dark/FileTypes/app.png"]
        globals.systemIcon = [tk.PhotoImage(file=globals.file_path + "dark/FileTypes/system.png"), "dark/FileTypes/system.png"]
        globals.fontFileIcon = [tk.PhotoImage(file=globals.file_path + "dark/FileTypes/font.png"), "dark/FileTypes/font.png"]
        globals.zipIcon = [tk.PhotoImage(file=globals.file_path + "dark/FileTypes/zip.png"), "dark/FileTypes/zip.png"]

        # UI Icons
        globals.backIcon = [tk.PhotoImage(file=globals.file_path + "dark/back.png"), "dark/back.png"]
        globals.frontIcon = [tk.PhotoImage(file=globals.file_path + "dark/front.png"), "dark/front.png"]
        globals.copyIcon = [tk.PhotoImage(file=globals.file_path + "dark/copy.png"), "dark/copy.png"]
        globals.cpuIcon = [tk.PhotoImage(file=globals.file_path + "dark/cpu.png"), "dark/cpu.png"]
        globals.deleteIcon = [tk.PhotoImage(file=globals.file_path + "dark/delete.png"), "dark/delete.png"]
        globals.driveIcon = [tk.PhotoImage(file=globals.file_path + "dark/drive.png"), "dark/drive.png"]
        globals.fontIcon = [tk.PhotoImage(file=globals.file_path + "dark/font.png"), "dark/font.png"]
        globals.appIcon = [tk.PhotoImage(file=globals.file_path + "dark/app.png"), "dark/window.png"]
        globals.infoIcon = [tk.PhotoImage(file=globals.file_path + "dark/info.png"), "dark/info.png"]
        globals.memoryIcon = [tk.PhotoImage(file=globals.file_path + "dark/memory.png"), "dark/memory.png"]
        globals.networkIcon = [tk.PhotoImage(file=globals.file_path + "dark/network.png"), "dark/network.png"]
        globals.pasteIcon = [tk.PhotoImage(file=globals.file_path + "dark/paste.png"), "dark/paste.png"]
        globals.pieIcon = [tk.PhotoImage(file=globals.file_path + "dark/pie.png"), "dark/pie.png"]
        globals.processIcon = [tk.PhotoImage(file=globals.file_path + "dark/process.png"), "dark/process.png"]
        globals.reloadIcon = [tk.PhotoImage(file=globals.file_path + "dark/reload.png"), "dark/reload.png"]
        globals.renameIcon = [tk.PhotoImage(file=globals.file_path + "dark/rename.png"), "dark/rename.png"]
        globals.scaleIcon = [tk.PhotoImage(file=globals.file_path + "dark/scale.png"), "dark/scale.png"]
        globals.themesIcon = [tk.PhotoImage(file=globals.file_path + "dark/themes.png"), "dark/themes.png"]
        globals.exitIcon = [tk.PhotoImage(file=globals.file_path + "dark/exit.png"), "dark/exit.png"]
        globals.gdriveIcon = [tk.PhotoImage(file=globals.file_path + "dark/gdrive.png"), "dark/gdrive.png"]
        globals.configIcon = [tk.PhotoImage(file=globals.file_path + "dark/settings.png"), "dark/settings.png"]
        globals.keybindIcon = [tk.PhotoImage(file=globals.file_path + "dark/keyboard.png"), "dark/keyboard.png"]
        globals.windowIcon = [tk.PhotoImage(file=globals.file_path + "dark/window.png"), "dark/window.png"]
        globals.winconfigIcon = [tk.PhotoImage(file=globals.file_path + "dark/winconfig.png"), "dark/winconfig.png"]
        globals.userIcon = [tk.PhotoImage(file=globals.file_path + "dark/user.png"), "dark/user.png"]
        globals.opacityIcon = [tk.PhotoImage(file=globals.file_path + "dark/opacity.png"), "dark/opacity.png"]
        globals.tabIcon = [tk.PhotoImage(file=globals.file_path + "dark/tablet.png"), "dark/tablet.png"]
        globals.dfIcon = [tk.PhotoImage(file=globals.file_path + "dark/df.png"), "dark/df.png"]
        globals.onedrvIcon = [tk.PhotoImage(file=globals.file_path + "dark/onedrive.png"), "dark/onedrive.png"]

    # Header Frame
    
    if bootstyle == "light":
        refreshIcon = tk.PhotoImage(file=globals.file_path + "\\light\\reload.png")
        backArrowIcon = tk.PhotoImage(file=globals.file_path + "\\light\\back.png")
        frontArrowIcon = tk.PhotoImage(file=globals.file_path + "\\light\\front.png")
        copyIcon = tk.PhotoImage(file=globals.file_path + "\\light\\copy.png")
        pasteIcon = tk.PhotoImage(file=globals.file_path + "\\light\\paste.png")
        deleteIcon = tk.PhotoImage(file=globals.file_path + "\\light\\delete.png")
        renameIcon = tk.PhotoImage(file=globals.file_path + "\\light\\rename.png")
        settingsIcon = tk.PhotoImage(file=globals.file_path + "\\light\\process.png")
        infoIcon = tk.PhotoImage(file=globals.file_path + "\\light\\info.png")
        appIcon = tk.PhotoImage(file=globals.file_path + "\\light\\window.png")
        adminIcon = tk.PhotoImage(file=globals.file_path + "\\light\\user.png")
    else:
        refreshIcon = tk.PhotoImage(file=globals.file_path + "\\dark\\reload.png")
        backArrowIcon = tk.PhotoImage(file=globals.file_path + "\\dark\\back.png")
        frontArrowIcon = tk.PhotoImage(file=globals.file_path + "\\dark\\front.png")
        copyIcon = tk.PhotoImage(file=globals.file_path + "\\dark\\copy.png")
        pasteIcon = tk.PhotoImage(file=globals.file_path + "\\dark\\paste.png")
        deleteIcon = tk.PhotoImage(file=globals.file_path + "\\dark\\delete.png")
        renameIcon = tk.PhotoImage(file=globals.file_path + "\\dark\\rename.png")
        settingsIcon = tk.PhotoImage(file=globals.file_path + "\\dark\\process.png")
        infoIcon = tk.PhotoImage(file=globals.file_path + "\\dark\\info.png")
        appIcon = tk.PhotoImage(file=globals.file_path + "\\dark\\window.png")
        adminIcon = tk.PhotoImage(file=globals.file_path + "\\dark\\user.png")

    if (globals.theme_mode == "light" or globals.theme_mode == "mLight"):
        sidebarDrivesIcon = tk.PhotoImage(file=globals.file_path + "\\light\\drive.png")
        sidebarPinsIcon = tk.PhotoImage(file=globals.file_path + "\\light\\window.png")
    else:
        sidebarDrivesIcon = tk.PhotoImage(file=globals.file_path + "\\dark\\drive.png")
        sidebarPinsIcon = tk.PhotoImage(file=globals.file_path + "\\dark\\window.png")
    headerFrame = ttk.Frame(padding=[10,0])

    
    # Footer Frame
    footerFrame = ttk.Frame(window, padding=[10,0])
    globals.footer = ttk.Label(footerFrame)
    # --Footer Frame

    searchEntry = ttk.Entry(footerFrame, width=30, font=(fontstyle, globals.font_size), bootstyle=bootstyle)
    searchEntry.insert(0, "Search Files.." )
    searchEntry.bind("<Button-1>", partial(func.click, searchEntry))
    searchEntry.bind("<FocusOut>", partial(func.FocusOut, searchEntry, window))

    globals.cwdLabel = ttk.Entry(headerFrame, width=30, font=(fontstyle, globals.font_size), bootstyle=bootstyle)
    globals.cwdLabel.bind("<FocusOut>", partial(func.FocusOut, searchEntry, window))


    backButton = ttk.Button(
        headerFrame,
        image=backArrowIcon,
        command=func.previous,
        bootstyle=bootstyle,
        takefocus=False
    )
    forwardButton = ttk.Button(
        headerFrame,
        image=frontArrowIcon,
        command=func.next,
        bootstyle=bootstyle,
        takefocus=False
    )
    def show_menu(event=None):
        menu.post(event.x_root, event.y_root)
    
    # Create a context menu
    menu = ttk.Menu(window, tearoff=False, font=(fontstyle, globals.font_size))
    if settingsEnabled == True:
        menu.add_command(label="File Information", command=fileInfo, foreground=theme_handler.menuFGItem)
        menu.add_command(label="File Settings", command=open_file_propertieshandler, foreground=theme_handler.menuFGItem)
    if adminEnabled == True:
        menu.add_command(label="Admin Mode", command=openAdminMode, foreground=theme_handler.menuFGItem)
    if explorerEnabled == True:
        menu.add_command(label="Open in Explorer", command=openInExplorer, foreground=theme_handler.menuFGItem)

    # Create the button
    moreButton = ttk.Button(
        footerFrame,
        image=settingsIcon,
        text=" More",
        compound=tk.LEFT,
        bootstyle=bootstyle,  # Update to match your desired bootstyle
        takefocus=False
    )

    # Bind right-click to show the context menu
    moreButton.bind("<Button-1>", show_menu)

    def show_edit_menu(event=None):
        editMenu.post(event.x_root, event.y_root)
    
    # Create a context menu
    editMenu = ttk.Menu(window, tearoff=False, font=(fontstyle, globals.font_size))
    if fileOpEnabled == True:
        editMenu.add_command(label="Copy Selected", command=func.copy, foreground=theme_handler.menuFGItem)
        editMenu.add_command(label="Paste Selected", command=func.paste, foreground=theme_handler.menuFGItem)
        editMenu.add_command(label="Delete Selected", command=del_file_popup, foreground=theme_handler.menuFGItem)
        editMenu.add_command(label="Rename Selected", command=rename_popup, foreground=theme_handler.menuFGItem)
   

    # Create the button
    edit2Button = ttk.Button(
        footerFrame,
        image=copyIcon,
        text=" Edit File",
        compound=tk.LEFT,
        bootstyle=bootstyle,  # Update to match your desired bootstyle
        takefocus=False
    )

   
    # Bind right-click to show the context menu
    edit2Button.bind("<Button-1>", show_edit_menu)

    def show_open_menu(event=None):
        openMenu.post(event.x_root, event.y_root)
    
    # Create a context menu
    openMenu = ttk.Menu(window, tearoff=False, font=(fontstyle, globals.font_size))
    if editWithEnabled == True:
        openMenu.add_command(label="Open File", command=func.onDoubleClick, foreground=theme_handler.menuFGItem)
        openMenu.add_command(label="Open File With", command=func.openWith, foreground=theme_handler.menuFGItem)
        openMenu.add_command(label="Open Terminal", command=start_terminal, foreground=theme_handler.menuFGItem)
        openMenu.add_command(label="Edit with Notepad", command=func.editFile, foreground=theme_handler.menuFGItem)
   
     # Create the button
    openButton = ttk.Button(
        footerFrame,
        image=appIcon,
        text=" Open",
        compound=tk.LEFT,
        bootstyle=bootstyle, takefocus=False  # Update to match your desired bootstyle
    )

   
    # Bind right-click to show the context menu
    openButton.bind("<Button-1>", show_open_menu)

    def show_create_menu(event=None):
        createMenu.post(event.x_root, event.y_root)
    
    # Create a context menu
    createMenu = ttk.Menu(window, tearoff=False, font=(fontstyle, globals.font_size))
    if createEnabled == True:
        createMenu.add_command(label="New File", command=new_file_popup, foreground=theme_handler.menuFGItem)
        createMenu.add_command(label="New Text File", command=new_txt_file, foreground=theme_handler.menuFGItem)
        createMenu.add_command(label="New Directory", command=new_dir_popup, foreground=theme_handler.menuFGItem)
   
    # Create the button
    createButton = ttk.Button(
        footerFrame,
        image=renameIcon,
        text=" Create",
        compound=tk.LEFT,
        bootstyle=bootstyle, takefocus=False  # Update to match your desired bootstyle
    )

   
    # Bind right-click to show the context menu
    createButton.bind("<Button-1>", show_create_menu)

    refreshButton = ttk.Button(
        footerFrame,
        command=partial(refresh, []),
        text=" Refresh",
        compound=tk.LEFT,
        image=refreshIcon,
        bootstyle=bootstyle, takefocus=False
    )


  

    # tooltips for buttons
    ToolTip(backButton, text="Back", bootstyle=("default", "inverse"))
    ToolTip(forwardButton, text="Forward", bootstyle=("default", "inverse"))
    ToolTip(refreshButton, text="Refresh", bootstyle=("default", "inverse"))
    # --Header Frame

    # imgs
    open_img = Image.open(globals.file_path + globals.appIcon[1])
    open_photo = ImageTk.PhotoImage(open_img)
    refresh_img = Image.open(globals.file_path + globals.reloadIcon[1])
    refresh_photo = ImageTk.PhotoImage(refresh_img)
    rename_img = Image.open(globals.file_path + globals.renameIcon[1])
    rename_photo = ImageTk.PhotoImage(rename_img)
    drive_img = Image.open(globals.file_path + globals.driveIcon[1])
    drive_photo = ImageTk.PhotoImage(drive_img)
    info_img = Image.open(globals.file_path + globals.infoIcon[1])
    info_photo = ImageTk.PhotoImage(info_img)
    pie_img = Image.open(globals.file_path + globals.pieIcon[1])
    pie_photo = ImageTk.PhotoImage(pie_img)
    cpu_img = Image.open(globals.file_path + globals.cpuIcon[1])
    cpu_photo = ImageTk.PhotoImage(cpu_img)
    memory_img = Image.open(globals.file_path + globals.memoryIcon[1])
    memory_photo = ImageTk.PhotoImage(memory_img)
    network_img = Image.open(globals.file_path + globals.networkIcon[1])
    network_photo = ImageTk.PhotoImage(network_img)
    process_img = Image.open(globals.file_path + globals.processIcon[1])
    process_photo = ImageTk.PhotoImage(process_img)
    
    themes_img = Image.open(globals.file_path + globals.themesIcon[1])
    themes_photo = ImageTk.PhotoImage(themes_img)
    scale_img = Image.open(globals.file_path + globals.scaleIcon[1])
    scale_photo = ImageTk.PhotoImage(scale_img)
    font_img = Image.open(globals.file_path + globals.fontIcon[1])
    font_photo = ImageTk.PhotoImage(font_img)
    copy_img = Image.open(globals.file_path + globals.copyIcon[1])
    copy_photo = ImageTk.PhotoImage(copy_img)
    paste_img = Image.open(globals.file_path + globals.pasteIcon[1])
    paste_photo = ImageTk.PhotoImage(paste_img)
    delete_img = Image.open(globals.file_path + globals.deleteIcon[1])
    delete_photo = ImageTk.PhotoImage(delete_img)
    gdrive_img = Image.open(globals.file_path + globals.gdriveIcon[1])
    gdrive_photo = ImageTk.PhotoImage(gdrive_img)
    config_img = Image.open(globals.file_path + globals.configIcon[1])
    config_photo = ImageTk.PhotoImage(config_img)
    keybind_img = Image.open(globals.file_path + globals.keybindIcon[1])
    keybind_photo = ImageTk.PhotoImage(keybind_img)
    window_img = Image.open(globals.file_path + globals.windowIcon[1])
    window_photo = ImageTk.PhotoImage(window_img)
    winconfig_img = Image.open(globals.file_path + globals.winconfigIcon[1])
    winconfig_photo = ImageTk.PhotoImage(winconfig_img)
    user_img = Image.open(globals.file_path + globals.userIcon[1])
    user_photo = ImageTk.PhotoImage(user_img)
    opacity_img = Image.open(globals.file_path + globals.opacityIcon[1])
    opacity_photo = ImageTk.PhotoImage(opacity_img)
    tab_img = Image.open(globals.file_path + globals.tabIcon[1])
    tab_photo = ImageTk.PhotoImage(tab_img)
    df_img = Image.open(globals.file_path + globals.dfIcon[1])
    df_photo = ImageTk.PhotoImage(df_img)
    onedrv_img = Image.open(globals.file_path + globals.onedrvIcon[1])
    onedrive_photo = ImageTk.PhotoImage(onedrv_img)

    # File Type icons
    file_img = Image.open(globals.file_path + globals.fileIcon[1])
    file_photo = ImageTk.PhotoImage(file_img)
    dir_img = Image.open(globals.file_path + globals.folderIcon[1])
    dir_photo = ImageTk.PhotoImage(dir_img)
    doc_img = Image.open(globals.file_path + globals.docIcon[1])
    doc_photo = ImageTk.PhotoImage(doc_img)
    photo_img = Image.open(globals.file_path + globals.photoIcon[1])
    photo_photo = ImageTk.PhotoImage(photo_img)
    video_img = Image.open(globals.file_path + globals.videoIcon[1])
    video_photo = ImageTk.PhotoImage(video_img)
    audio_img = Image.open(globals.file_path + globals.audioIcon[1])
    audio_photo = ImageTk.PhotoImage(audio_img)
    exe_img = Image.open(globals.file_path + globals.exeIcon[1])
    exe_photo = ImageTk.PhotoImage(exe_img)
    system_img = Image.open(globals.file_path + globals.systemIcon[1])
    system_photo = ImageTk.PhotoImage(system_img)
    fontFile_img = Image.open(globals.file_path + globals.fontFileIcon[1])
    fontFile_photo = ImageTk.PhotoImage(fontFile_img)
    zip_img = Image.open(globals.file_path + globals.zipIcon[1])
    zip_photo = ImageTk.PhotoImage(zip_img)
    menuFontSize = int(globals.font_size)

    # Right click menu
    m = ttk.Menu(window, tearoff=False, font=(fontstyle, globals.font_size))
    m.add_command(label="Open File", compound="left", image=open_photo, font=(fontstyle, globals.font_size, "bold"))
    m.add_command(label="Open File", compound="left", command=func.onDoubleClick, foreground=theme_handler.menuFGItem)
    m.add_command(label="Open File With", compound="left", command=func.openWith, foreground=theme_handler.menuFGItem)
    m.add_separator()
    m.add_command(label="Edit", compound="left", image=copy_photo, font=(fontstyle, globals.font_size, "bold"))
    m.add_command(label="Copy Selected", compound="left", command=func.copy, foreground=theme_handler.menuFGItem)
    m.add_command(label="Paste Selected", compound="left", command=func.paste, foreground=theme_handler.menuFGItem)
    m.add_command(label="Delete Selected", compound="left", command=del_file_popup, foreground=theme_handler.menuFGItem)
    m.add_command(label="Rename Selected", compound="left", command=rename_popup, foreground=theme_handler.menuFGItem)
    m.add_separator()
    m.add_command(label="Properties", compound="left", image=info_photo, font=(fontstyle, globals.font_size, "bold"))
    m.add_command(label="File Info", compound="left", command=partial(fileInfo, []), foreground=theme_handler.menuFGItem)
    m.add_command(label="File Settings", compound="left", command=open_file_propertieshandler, foreground=theme_handler.menuFGItem)
    m.add_command(label="Pin to Side", compound="left", command=pinToSide, foreground=theme_handler.menuFGItem)

    s.configure(".", font=(fontstyle, globals.font_size))  # set font size
    s.configure("Treeview", rowheight=tvdense)  # customize treeview
    s.configure(
        "Treeview.Heading", font=(fontstyle, str(int(globals.font_size) + 1))
    )
    s.layout("Treeview", [("Treeview.treearea", {"sticky": "nswe"})])  # remove borders

    globals.items.column("#0", width=40, stretch=tk.NO)
    globals.items.column("Name", width=150, minwidth=120)
    globals.items.column("Date modified", width=100, minwidth=120)
    globals.items.column("Size", width=40, minwidth=60)
    globals.items.column("Type", width=90, minwidth=60)
    
    globals.items.heading(
        "Name",
        text="Name",
        anchor=tk.W,
        command=partial(func.sort_col, "Name", False),
        
    )
    globals.items.heading(
        "Date modified",
        text="Date modified",
        anchor=tk.W,
        command=partial(func.sort_col, "Date modified", False),
    )
    globals.items.heading(
        "Type",
        text="Type",
        anchor=tk.W,
        command=partial(func.sort_col, "Type", False),
    )
    globals.items.heading(
        "Size",
        text="Size",
        anchor=tk.W,
        command=partial(func.sort_col, "Size", False),
    )
    globals.items.bind(
        "<Double-1>",
        func.onDoubleClick,
    )  # command on double click
    globals.items.bind("<ButtonRelease-1>", func.selectItem)
    globals.items.bind("<Button-3>", partial(func.onRightClick, m))  # command on right click

    globals.items.bind("<Up>", func.up_key)  # bind up arrow key
    globals.items.bind("<Down>", func.down_key)  # bind down arrow key
    # --Browse Frame
    menuFontSize = int(globals.font_size)

 
    # --Menu window

    menubarFrame = ttk.Frame(padding=[10,0])
    # Allow the title bar to be draggable
    def start_move(event):
        window.x = event.x
        window.y = event.y

    def stop_move(event):
        window.x = None
        window.y = None

    def on_motion(event):
        delta_x = event.x - window.x
        delta_y = event.y - window.y
        new_x = window.winfo_x() + delta_x
        new_y = window.winfo_y() + delta_y
        window.geometry(f"+{new_x}+{new_y}")

    menubarFrame.bind("<ButtonPress-1>", start_move)
    menubarFrame.bind("<ButtonRelease-1>", stop_move)
    menubarFrame.bind("<B1-Motion>", on_motion)
    def adjust_color(hex_color, adjustment):
        # Convert hex to RGB
        r, g, b = ImageColor.getrgb(hex_color)
        # Adjust color by subtracting adjustment value
        r = max(0, r - adjustment)
        g = max(0, g - adjustment)
        b = max(0, b - adjustment)
        # Convert back to hex
        return f'#{r:02x}{g:02x}{b:02x}'

    # Get the window's background color
    window_bg = window.cget("background")
    if globals.theme_mode == "mLight" or globals.theme_mode == "light":
        window_fg = "#000000"
    else:
        window_fg = "#ffffff"

    # Adjust the hover color (for example, subtracting 50)
    hover_color = adjust_color(window_bg, 8)
    style = ttk.Style()
    # Create a custom button style
    style.configure("Custom.TButton", background=window_bg, borderwidth=0, foreground=window_fg)
    style.map("Custom.TButton",
              background=[('active', hover_color), ('!active', window_bg)],  # Change to your desired hover color
              relief=[('pressed', 'raised'), ('!pressed', 'raised')])

    s = ttk.Style()
    s.configure(".", font=(fontstyle, globals.font_size))  # set font size

    def show_window_actions(event=None):
        winActions_menu.post(event.x_root, event.y_root)

    def show_menu(event=None):
        file_menu.post(event.x_root, event.y_root)
   

    def show_topedit_menu(event=None):
        subfile.post(event.x_root, event.y_root)



    def show_drives_menu(event=None):
        drives_menu.post(event.x_root, event.y_root)


    def show_tools_menu(event=None):
        tools.post(event.x_root, event.y_root)



    def show_view_menu(event=None):
        view_menu.post(event.x_root, event.y_root)

    def show_system_menu(event=None):
        system_menu.post(event.x_root, event.y_root)
     
    def show_settings_menu(event=None):
        settings_menu1.post(event.x_root, event.y_root)
    
    # Create a context menu
    winActions_menu = ttk.Menu(window, tearoff=False, font=(fontstyle, menuFontSize)); winActions_menu.add_command(label="Zero Files 2025", image=opacity_photo, compound="left", font=(fontstyle, menuFontSize, "bold")); winActions_menu.add_command(label="Minimise", compound="left", command=window.iconify, foreground=theme_handler.menuFGItem); winActions_menu.add_command(label="Maximise", compound="left", command=lambda: window.geometry(f"{window.winfo_screenwidth()}x{window.winfo_screenheight()}+0+0"), foreground=theme_handler.menuFGItem);winActions_menu.add_command(label="Restart", compound="left", command=restart_shell, foreground=theme_handler.menuFGItem); winActions_menu.add_command(label="Exit", compound="left", command=quit, foreground=theme_handler.menuFGItem)

    file_menu = ttk.Menu(window, tearoff=False, font=(fontstyle, globals.font_size)); file_menu.add_cascade(label="Open File", image=open_photo, compound="left", font=(fontstyle, menuFontSize, "bold")); file_menu.add_command(label="Open", compound="left", command=func.onDoubleClick, foreground=theme_handler.menuFGItem); file_menu.add_command(label="Open With", compound="left", command=util.apps, foreground=theme_handler.menuFGItem); file_menu.add_separator(); file_menu.add_cascade(label="New Window", image=window_photo, compound="left", font=(fontstyle, menuFontSize, "bold")); file_menu.add_command(label="Standard Window", compound="left", command=util.stwin, foreground=theme_handler.menuFGItem); file_menu.add_command(label="Admin Window", compound="left", command=util.adwin, foreground=theme_handler.menuFGItem); file_menu.add_command(label="Terminal Window", compound="left", command=start_terminal, foreground=theme_handler.menuFGItem)

    subfile = ttk.Menu(window, tearoff=False, font=(fontstyle, menuFontSize)); subfile.add_command(label="Create", compound="left", image=open_photo, font=(fontstyle, menuFontSize, "bold")); subfile.add_command(label="File", compound="left", command=new_file_popup, foreground=theme_handler.menuFGItem); subfile.add_command(label="Directory", compound="left", command=new_dir_popup, foreground=theme_handler.menuFGItem); subfile.add_separator(); subfile.add_command(label="Edit", image=copy_photo, compound="left", font=(fontstyle, menuFontSize, "bold")); subfile.add_command(label="Copy Selected", compound="left", command=func.copy, foreground=theme_handler.menuFGItem); subfile.add_command(label="Paste Selected", compound="left", command=func.paste, foreground=theme_handler.menuFGItem); subfile.add_command(label="Delete Selected", compound="left", command=del_file_popup, foreground=theme_handler.menuFGItem); subfile.add_command(label="Rename Selected", compound="left", command=rename_popup, foreground=theme_handler.menuFGItem); subfile.add_separator(); subfile.add_command(label="File Tools", compound="left", image=info_photo, font=(fontstyle, globals.font_size, "bold")); subfile.add_command(label="Information", compound="left", command=partial(fileInfo, []), foreground=theme_handler.menuFGItem); subfile.add_command(label="Settings", compound="left", command=open_file_propertieshandler, foreground=theme_handler.menuFGItem)

    drives_menu = ttk.Menu(window, tearoff=True, font=(fontstyle, menuFontSize)); drives_menu.add_command(label="Drives", image=pie_photo, compound="left", font=(fontstyle, menuFontSize, "bold")); drives_menu.add_command(label="Storage Analysis", command=partial(util.drive_stats, window), foreground=theme_handler.menuFGItem); drives_menu.add_command(label="Manage Partitions", command=util.diskmgr, foreground=theme_handler.menuFGItem); drives_menu.add_separator(); drives_menu.add_command(label="Storage", image=memory_photo, compound="left", font=(fontstyle, menuFontSize, "bold")); [drives_menu.add_command(label=drive + "\ ", compound="left", command=partial(func.cd_drive, drive, []), foreground=theme_handler.menuFGItem) for drive in globals.available_drives]

    tools = ttk.Menu(window, tearoff=False, font=(fontstyle, menuFontSize)); tools.add_command(label="OneDrive Backup", image=onedrive_photo, compound="left", font=(fontstyle, menuFontSize, "bold")); tools.add_command(label="Backup Selected", compound="left", command=onedrive_backup, foreground=theme_handler.menuFGItem); tools.add_command(label="View OneDrive", compound="left", command=func.onedrivedir, foreground=theme_handler.menuFGItem); tools.add_command(label="About OneDrive Backup", compound="left", command=util.od_popup, foreground=theme_handler.menuFGItem)


    view_menu = ttk.Menu(window, tearoff=True, font=(fontstyle, menuFontSize)); view_menu.add_command(label="Zoom", image=scale_photo, compound="left", font=(fontstyle, menuFontSize, "bold")); view_menu.add_command(label="150%", command=partial(func.change_scale, 1.5, s), foreground=theme_handler.menuFGItem); view_menu.add_command(label="125%", command=partial(func.change_scale, 1.25, s), foreground=theme_handler.menuFGItem); view_menu.add_command(label="100%", command=partial(func.change_scale, 1.0, s), foreground=theme_handler.menuFGItem); view_menu.add_command(label="75%", command=partial(func.change_scale, 0.75, s), foreground=theme_handler.menuFGItem); view_menu.add_command(label="50%", command=partial(func.change_scale, 0.5, s), foreground=theme_handler.menuFGItem)

    system_menu = ttk.Menu(window, tearoff=True, font=(fontstyle, menuFontSize)); system_menu.add_command(label="Performance", image=cpu_photo, compound="left", font=(fontstyle, menuFontSize, "bold")); system_menu.add_command(label="CPU", compound="left", command=util.cpu_stats, foreground=theme_handler.menuFGItem); system_menu.add_command(label="Memory", compound="left", command=util.memory_stats, foreground=theme_handler.menuFGItem); system_menu.add_command(label="Network", compound="left", command=util.network_stats, foreground=theme_handler.menuFGItem); system_menu.add_command(label="Processes", compound="left", command=partial(util.processes_win), foreground=theme_handler.menuFGItem)

    settings_menu1 = ttk.Menu(window, tearoff=False, font=(fontstyle, menuFontSize)); settings_menu1.add_command(label="Preferences", image=config_photo, compound="left", font=(fontstyle, menuFontSize, "bold")); settings_menu1.add_command(label="Settings", command=start_settings, compound="left", foreground=theme_handler.menuFGItem); settings_menu1.add_command(label="Themes", command=settings.themeConfigFromApp, compound="left", foreground=theme_handler.menuFGItem); settings_menu1.add_separator(); settings_menu1.add_command(label="Help and About", image=info_photo, compound="left", font=(fontstyle, menuFontSize, "bold")); settings_menu1.add_command(label="Keyboard Shortcuts", command=util.key_popup, compound="left", foreground=theme_handler.menuFGItem); settings_menu1.add_command(label="Open Source Licenses", command=util.osl_popup, foreground=theme_handler.menuFGItem); settings_menu1.add_command(label="About Zero Files", command=util.about_popup, compound="left", foreground=theme_handler.menuFGItem)

    #an image (make sure to have a valid path to your image)
    if (globals.theme_mode == "mLight") or (globals.theme_mode == "light"):
        original_image = Image.open(r"C:\Zero Software\ZeroFiles\zeroicon.png")  # Replace with your image file path
    else:
        original_image = Image.open(r"C:\Zero Software\ZeroFiles\zeroicon_dark.png")  # Replace with your image file path
        
    # Resize the image (change 500, 500 to whatever dimensions you want)
    resized_image = original_image.resize((25, 25))

    # Convert the image to a format Tkinter understands
    image = ImageTk.PhotoImage(resized_image)

    # Create a Label widget to display the image
    zFileLabel = tk.Label(menubarFrame, image=image, compound=tk.LEFT, font=(fontstyle, globals.font_size, "bold"))
    fileButton = ttk.Button(menubarFrame, text="File", compound=tk.LEFT, style="Custom.TButton", takefocus=False)
    editButton = ttk.Button(menubarFrame, text="Edit", compound=tk.LEFT, style="Custom.TButton", takefocus=False)
    drivesButton = ttk.Button(menubarFrame, text="Drives", compound=tk.LEFT, style="Custom.TButton", takefocus=False)
    toolsButton = ttk.Button(menubarFrame, text="Cloud", compound=tk.LEFT, style="Custom.TButton", takefocus=False)
    sysButton = ttk.Button(menubarFrame, text="System", compound=tk.LEFT, style="Custom.TButton", takefocus=False)
    viewButton = ttk.Button(menubarFrame, text="View", compound=tk.LEFT, style="Custom.TButton", takefocus=False)
    settingsButton = ttk.Button(menubarFrame, text="Settings", compound=tk.LEFT, style="Custom.TButton", takefocus=False)
    window.image = image

    
    # Bind right-click to show the context menu
    zFileLabel.bind("<Button-1>", show_window_actions)
    fileButton.bind("<Button-1>", show_menu)
    editButton.bind("<Button-1>", show_topedit_menu)
    drivesButton.bind("<Button-1>", show_drives_menu)
    viewButton.bind("<Button-1>", show_view_menu)
    sysButton.bind("<Button-1>", show_system_menu)
    toolsButton.bind("<Button-1>", show_tools_menu)
    settingsButton.bind("<Button-1>", show_settings_menu)

    zFileLabel.pack(side=tk.LEFT,  padx=2, pady=10, fill=tk.BOTH)
    fileButton.pack(side=tk.LEFT,  padx=2, pady=10, fill=tk.BOTH)
    editButton.pack(side=tk.LEFT,  padx=2, pady=10, fill=tk.BOTH)
    drivesButton.pack(side=tk.LEFT,  padx=2, pady=10, fill=tk.BOTH)

    if toolToolEnabled == True:
        toolsButton.pack(side=tk.LEFT,  padx=2, pady=10, fill=tk.BOTH)
    if sysToolEnabled == True:
        sysButton.pack(side=tk.LEFT,  padx=2, pady=10, fill=tk.BOTH)
    
    
    if viewToolEnabled == True:
        viewButton.pack(side=tk.LEFT,  padx=2, pady=10, fill=tk.BOTH)
    settingsButton.pack(side=tk.LEFT,  padx=2, pady=10, fill=tk.BOTH)

    menubarFrame.pack(fill=tk.X)  # Use sticky for east and west to fill horizontally

    sidebar = ttk.Frame(padding=[10,0])
    driveSidebar = ttk.Frame(
        sidebar,
        padding=[0,0]
    )
    # Create the button
    drivesHead = ttk.Label(
        driveSidebar,
        text=" Drives",
        image=sidebarDrivesIcon,
        compound=tk.LEFT,
        style="Custom.TButton"

    )
    
    drivesHead.grid(row=0, column=0, padx=2, pady=5, sticky="w")
    for index, drive in enumerate(globals.available_drives):
        ttk.Button(
            driveSidebar,
            text=drive + "\\",
            compound="left",
            command=partial(func.cd_drive, drive, []),
            style="Custom.TButton", takefocus=False
        ).grid(row=index+1, column=0, padx=2, pady=5, sticky="w")

    
    pinsSidebar = ttk.Frame(
        sidebar,
        padding=[0,0]
    )
    btn1 = ttk.Label(
        pinsSidebar,
        text=" My Pins",
        image=sidebarPinsIcon,
        compound=tk.LEFT,
        style="Custom.TButton"

    )
    managePinButton = ttk.Button(
        pinsSidebar,
        text="Manage Pins",
        command=managePins,
        compound=tk.LEFT,
        style="Custom.TButton"

    )
    import json
    FILE_PATH = 'C:\\Zero Software\\ZeroFiles\\res\\Pins\\pins.json'
    def load_pins():
        if os.path.exists(FILE_PATH):
            with open(FILE_PATH, 'r') as file:
                return json.load(file)
        return []  # Return an empty list if the file doesn't exist
    pins = load_pins()
    print(pins)
    for i, pin in enumerate(pins):
        ttk.Button(pinsSidebar, text=pin["name"], compound=tk.LEFT, style="Custom.TButton", command=lambda p=pin["path"]: func.openPin(p), takefocus=False).grid(row=i + 2, column=0, padx=2, pady=5, sticky="w")

    
    btn1.grid(row=0, column=0, padx=2, pady=5, sticky="w")
    managePinButton.grid(row=1, column=0, padx=2, pady=5, sticky="w")
    driveSidebar.pack(fill=tk.X)
    ttk.Separator(sidebar).pack(fill="x", pady=10)
    pinsSidebar.pack(fill=tk.Y)
    sidebar.pack(fill=tk.Y, side=tk.LEFT)
    # packs
    scroll.pack(side=tk.RIGHT, fill=tk.BOTH)
    backButton.pack(side=tk.LEFT, padx=5, pady=10, fill=tk.BOTH)
    forwardButton.pack(side=tk.LEFT, padx=5, pady=10, fill=tk.BOTH)

    refreshButton.pack(side=tk.LEFT, padx=2, pady=10, fill=tk.BOTH)
    if editWithEnabled == True:
        openButton.pack(side=tk.LEFT, padx=2, pady=10, fill=tk.BOTH)
    
    if createEnabled == True:
        createButton.pack(side=tk.LEFT, padx=2, pady=10, fill=tk.BOTH)

    if fileOpEnabled == True or editWithEnabled == True:
        edit2Button.pack(side=tk.LEFT, padx=2, pady=10, fill=tk.BOTH)
    
    if adminEnabled == True or settingsEnabled == True or explorerEnabled == True:
        moreButton.pack(side=tk.LEFT, padx=2, pady=10, fill=tk.BOTH)
    
    globals.cwdLabel.pack(side=tk.LEFT, padx=10, pady=10, fill=tk.BOTH, expand=True)
    searchEntry.pack(side=tk.RIGHT, padx=5, pady=10, fill=tk.BOTH)

    
    headerFrame.pack(fill=tk.X)
    footerFrame.pack(side=quickAccessBarPos, fill=tk.BOTH)
    
    browseFrame.pack(fill=tk.BOTH, expand=True)

    globals.cwdLabel.bind(
        "<Return>",
        partial(func.setPathDest, globals.cwdLabel),
    )  #

    searchEntry.bind(
        "<Return>",
        partial(func.search, searchEntry),
    )  # on enter press, run search1

    # img references
    globals.photo_ref.extend([sidebarDrivesIcon, settingsIcon, sidebarPinsIcon, adminIcon, appIcon, infoIcon, backArrowIcon, frontArrowIcon, copyIcon, pasteIcon, deleteIcon, renameIcon, refreshIcon])
    globals.photo_ref.extend([open_photo, refresh_photo, rename_photo, drive_photo, info_photo, pie_photo, cpu_photo, memory_photo, network_photo, process_photo])
    globals.photo_ref.extend([file_photo, dir_photo, themes_photo, scale_photo, font_photo, copy_photo, paste_photo, delete_photo, gdrive_photo, config_photo])
    globals.photo_ref.extend([keybind_photo, window_photo, winconfig_photo, user_photo, opacity_photo, tab_photo, df_photo, onedrive_photo, doc_photo, photo_photo, video_photo, audio_photo, exe_photo, system_photo, fontFile_photo, zip_photo])

# popups
def warning_popup():
    Messagebox.show_info(
        message="Zero needs to restart to continue.", title="Restart Pending"
    )
def restart_shell():
    os.startfile(r"C:\Zero Software\ZeroFiles\src\main.pyw")
    quit()

def change_font_popup(size):
    func.change_font_size(size)

def new_file_popup():
    name = Querybox.get_string(prompt="Name: ", title="New file")
    if name is None:
        name = ""
    if name != "":
        try:
            f = open(os.getcwd() + "/" + name, "x")
            f.close()
            refresh([])
        except Exception as e:
            Messagebox.ok(
                title="Error",
                message="Unable to delete file\n" + str(e)
            )
            print(e)
            pass

def new_txt_file():
    name = Querybox.get_string(prompt="Name: ", title="New TXT file")
    if name is None:
        name = ""
    if name != "":
        try:
            f = open(os.getcwd() + "/" + name + ".txt", "x")
            f.close()
            refresh([])
        except Exception as e:
            Messagebox.ok(
                title="Error",
                message="Unable to delete file\n" + str(e)
            )
            print(e)
            pass

def new_dir_popup():
    name = Querybox.get_string(prompt="Name: ", title="New directory")
    if name is None:
        name = ""
    if name != "":
        try:
            os.mkdir(os.getcwd() + "/" + name)
            refresh([])
        except Exception as e:
            print(e)
            pass
def rename_popup():
    #global items
    if globals.items.focus() != "":
        try:
            name = Querybox.get_string(prompt="Select a new name: ", title="Rename")
            old = os.getcwd() + "/" + globals.selectedItem
            if name is None:
                name = ""
            os.rename(old, name)
            refresh([])
        except Exception as e:
            print(e)
            pass
    else:
        Messagebox.show_info(
            message="There is no selected file or directory.", title="Info"
        )
def onedrive_backup():
    #global items
    if globals.items.focus() != "":
        try:
            func.backup_file()
        except Exception as e:
            print(e)
            pass
    else:
        Messagebox.show_info(
            message="There is no selected file or directory.", title="Info"
        )
def paste_popup(t1):
    top = ttk.Toplevel(title="File Operation")
    top.geometry("250x50")
    top.resizable(False, False)

    gauge = ttk.Floodgauge(
        top, bootstyle="primary", mode="indeterminate", text="Copying files..."
    )
    gauge.pack(fill=tk.BOTH, expand=tk.YES)
    gauge.start()
    t1.join()
    refresh([])
    top.destroy()
def del_file_popup():
    #global items
    if globals.items.focus() != "":  # if there is a focused item
        answer = Messagebox.yesno(
            message="DELETE\nDeleting in Zero will skip the recycle bin and permanently delete the file. Do you wish to continue?",
            alert=True,
        )
        if answer == "Yes":
            func.del_file()
            refresh([])
        else:
            return
    else:
        Messagebox.show_info(
            message="There is no selected file or directory.", title="Info"
        )
def quit_program():
    quit()