import os
import shutil
import util
import globals
import threading
from datetime import datetime
import time
import subprocess
from tkinter import filedialog

from functools import partial
from sys import platform
import ui

import ttkbootstrap as ttk
import tkinter as tk

from PIL import Image, ImageTk
from ttkbootstrap.dialogs.dialogs import Messagebox
from ttkbootstrap.dialogs.dialogs import Querybox
from ttkbootstrap.tooltip import ToolTip
from ttkbootstrap.constants import *


def openMacro():
    os.startfile("C:\\Zero Software\\main.pyw")
def load_tvdensity_file():
    try:
        file_path = "C:\\Zero Software\\ZeroFiles\\res\\window\\tvdensity.txt"
        
        with open(file_path, "r") as file:
            content = file.read().strip()
        
        tvdense = int(content)
        return tvdense
    except Exception as e:
        print(f"Error loading file: {e}")
        return None

# Load the tvdense value
tvdense = load_tvdensity_file()
if tvdense is not None:
    pass
else:
    tvdense = 40  # Default value if loading fails
    
def checkPlatform():
    # global currDrive, available_drives
    if platform == "win32":
        globals.available_drives = [
            chr(x) + ":" for x in range(65, 91) if os.path.exists(chr(x) + ":")
        ]  # 65-91 -> search for drives A-Z
        globals.currDrive = globals.available_drives[0]  # current selected drive
    elif platform == "linux":
        globals.available_drives = "/"
        globals.currDrive = globals.available_drives


def read_theme():
    # global theme, file_path
    with open(globals.file_path + "../res/theme.txt") as f:  # closes file automatically
        globals.theme = f.readline()
        if (globals.theme == globals.literaL or globals.theme == globals.journalL 
            or globals.theme == globals.flatlyL or globals.theme == globals.morphL or globals.theme == globals.yetiL or globals.theme == globals.cerculeanL):
            globals.theme_mode = "mLight"
        elif (globals.theme == globals.cosmoL or globals.theme == globals.lumenL or globals.theme == globals.lumenL or globals.theme == globals.mintyL or globals.theme == globals.pulseL or globals.theme == globals.sandstoneL or globals.theme == globals.unitedL or globals.theme == globals.simplexL):
            globals.theme_mode = "light"
        else:
            globals.theme_mode = "dark"
    if globals.theme == "":  # if theme.txt is empty, set default theme
        globals.theme = globals.literaL
        globals.theme_mode = "light"


def read_font():
    #global font_size
    with open(globals.file_path + "../res/font.txt") as f:  # closes file automatically
        globals.font_size = f.readline()
    if globals.font_size == "":  # if font.txt is empty, set default font
        globals.font_size = 10


def click(searchEntry, event):
    if searchEntry.get() == "Search Files..":
        searchEntry.delete(0, "end")


def setPathDest(searchEntry, event):
    query = searchEntry.get() 
    try:
        os.chdir(query)
        ui.refresh([])
    except Exception as e:
        Messagebox.show_error(
            title="Error 0x70746845",
            message="An error occured while locating the path\n" + str(e),
            alert=True
        )



def FocusOut(searchEntry, window, event):
    window.focus()


def previous():
    #global lastDirectory
    globals.lastDirectory = os.getcwd()
    os.chdir("../")
    ui.refresh([])


def setPath():
    newpath = Querybox.get_string(
        title="Quick Path",
        prompt="Select Path:",
        initialvalue="C:\Windows",
        
    )
    try:
        os.chdir(newpath)
        ui.refresh([])
    except Exception as e:
        # Convert the exception to a string to display it properly in the message box
        error_message = str(e)
        Messagebox.ok(
            title="Error",
            message=error_message,
            alert=True
        )

    

def next():
    try:
        os.chdir(globals.lastDirectory)
        ui.refresh([])
    except Exception as e:
        print(e)
        return



def onDoubleClick(event=None):
    #global items
    iid = globals.items.focus()
    # iid = items.identify_row(event.y) # old
    if iid == "":  # if double click on blank, don't do anything
        return
    for item in globals.items.selection():
        tempDictionary = globals.items.item(item)
        tempName = tempDictionary["values"][0]  # get first value of dictionary
    try:
        newPath = os.getcwd() + "/" + tempName
        if os.path.isdir(
            newPath
        ):  # if file is directory, open directory else open file
            os.chdir(newPath)
        else:
            os.startfile(newPath)
        ui.refresh([])
    except Exception as e:
        print(e)
        Messagebox.show_info(
            message="An error occured opening the file/directory.\n" + str(e), title="Error 4B6E4F76"
        )
        os.chdir("..")
        ui.refresh([])

def onDoubleClick(event=None):
    #global items
    iid = globals.items.focus()
    # iid = items.identify_row(event.y) # old
    if iid == "":  # if double click on blank, don't do anything
        return
    for item in globals.items.selection():
        tempDictionary = globals.items.item(item)
        tempName = tempDictionary["values"][0]  # get first value of dictionary
    try:
        newPath = os.getcwd() + "/" + tempName
        if os.path.isdir(
            newPath
        ):  # if file is directory, open directory else open file
            os.chdir(newPath)
        else:
            os.startfile(newPath)
        ui.refresh([])
    except Exception as e:
        print(e)
        Messagebox.show_info(
            message="An error occured opening the file/directory.\n" + str(e), title="Error z4B6E4F76"
        )
        os.chdir("..")
        ui.refresh([])
        
def editFile():
    #global items
    iid = globals.items.focus()
    # iid = items.identify_row(event.y) # old
    if iid == "":  # if double click on blank, don't do anything
        return
    for item in globals.items.selection():
        tempDictionary = globals.items.item(item)
        tempName = tempDictionary["values"][0]  # get first value of dictionary
    try:
        newPath = os.getcwd() + "/" + tempName
        if os.path.isdir(
            newPath
        ):  # if file is directory, open directory else open file
            Messagebox.show_error(
                title="Error z496E636F6D70",
                message="The selected file isn't compatible with a text editor.\nPlease select a different one and try again"
            )
        else:
            subprocess.run(['notepad.exe', newPath])
        ui.refresh([])
    except Exception as e:
        print(e)
        Messagebox.show_info(
            message="An error occured opening the file/directory.\n" + str(e), title="Error z4B6E4F76"
        )
        ui.refresh([])

def openWith():
    #global items
    iid = globals.items.focus()
    # iid = items.identify_row(event.y) # old
    if iid == "":  # if double click on blank, don't do anything
        return
    for item in globals.items.selection():
        tempDictionary = globals.items.item(item)
        tempName = tempDictionary["values"][0]  # get first value of dictionary
    try:
        newPath = os.getcwd() + "/" + tempName
        if os.path.isdir(
            newPath
        ):  # if file is directory, open directory else open file
            Messagebox.show_error(
                title="Error z496E636F6D70",
                message="Directories cannot use the open with feature.\nPlease select a different file and try again"
            )
        else:
            file_path = filedialog.askopenfilename(
                title="Open " + newPath + " with",
                filetypes=[("Executables", "*.exe")],
                initialdir="C:\\Windows"
            )
            if file_path == "":
                pass
            else:
                subprocess.run([file_path, newPath])
        ui.refresh([])
    except Exception as e:
        print(e)
        Messagebox.show_info(
            message="An error occured opening the file/directory.\n" + str(e), title="Error z4B6E4F76"
        )
        ui.refresh([])

def homepage():
    try:
        homePage = os.path.expanduser("~")
        newPath = homePage
        if os.path.isdir(
            newPath
        ):  # if file is directory, open directory else open file
            os.chdir(newPath)
        else:
            os.startfile(newPath)
        ui.refresh([])
    except Exception as e:
        print(e)

        
        Messagebox.ok(
            message=r"The homepage file is missing, defaulting to C:\\Windows ",
            title="Error"
        )
        homepageerror()

def openPin(path):
    try:
        
        if os.path.isdir(
            path
        ):  # if file is directory, open directory else open file
            os.chdir(path)
        else:
            os.startfile(path)
        ui.refresh([])
    except Exception as e:
        print(e)

        
        Messagebox.ok(
            message=e, 
            title="Error"
        )

import json
# File path for saving the pins
FILE_PATH = 'C:\\Zero Software\\ZeroFiles\\res\\Pins\\pins.json'

# Load pins from file or initialize with default data
def load_pins():
    if os.path.exists(FILE_PATH):
        with open(FILE_PATH, 'r') as file:
            return json.load(file)
    return []

pins = load_pins()
# Save pins to file
def save_pins():
    with open(FILE_PATH, 'w') as file:
        json.dump(pins, file)
def add_pin(name, path):
    if name and path:
        pins.append({"name": name, "path": path})
        save_pins()  # Save changes
        Messagebox.ok(
            title="Restart Pending",
            message="Please restart Zero to update sidebar",
        )
    else:
        pass

def managePins():
    os.startfile("C:\\Zero Software\\pins.pyw")
def manageMacro():
    try:
        macro = "C:\\Zero Software\\Macros"
        newPath = macro
        if os.path.isdir(
            newPath
        ):  # if file is directory, open directory else open file
            os.chdir(newPath)
        else:
            os.startfile(newPath)
        ui.refresh([])
    except Exception as e:
        print(e)

def backupdir():
    try:
        onedrive_path_bk = os.getenv('OneDrive')
        newPath = onedrive_path_bk
        if os.path.isdir(
            newPath
        ):  # if file is directory, open directory else open file
            os.chdir(newPath)
        else:
            os.startfile(newPath)
        ui.refresh([])
    except Exception as e:
        print(e)

        
        Messagebox.ok(
            title="Error"
        )



def onedrivedir():
    try:
        onedrive_path = os.getenv('OneDrive')
        newPath = onedrive_path
        if os.path.isdir(
            newPath
        ):  # if file is directory, open directory else open file
            os.chdir(newPath)
        else:
            os.startfile(newPath)
        ui.refresh([])
    except Exception as e:
        print(e)

        
        Messagebox.ok(
            message=(e),
            title="Error"
        )

def homepageerror():
    try:
        newPath = r"\\Windows"
        if os.path.isdir(
            newPath
        ):  # if file is directory, open directory else open file
            os.chdir(newPath)
        else:
            os.startfile(newPath)
        ui.refresh([])
    except Exception as e:
        print(e)

        
        Messagebox.ok(
            message="The SYSTEMROOT could not be found",
            title="Error"
        )
        

def open_properties(path):
    # Convert path to absolute and format correctly for Windows
    path = os.path.abspath(path).replace('/', '\\')

    # Use `cmd` to open the Properties dialog
    command = f'explorer /select,"{path}"'
    os.system(command)

    # Simulate a key press (right-click context menu and select Properties)
    # We can use another system command for manual step if needed

def advancedprop(event=None):
    iid = globals.items.focus()
    if iid == "":  # if double click on blank, don't do anything
        return
    
    for item in globals.items.selection():
        tempDictionary = globals.items.item(item)
        tempName = tempDictionary["values"][0]  # get first value of dictionary
    
    try:
        newPath = os.path.join(os.getcwd(), tempName)
        if os.path.isdir(newPath):  # if file is directory, open directory else open file
            os.chdir(newPath)
        else:
            open_properties(newPath)
            
        ui.refresh([])
        util.prop_popup()
    except Exception as e:
        print(e)
        newPath = os.path.dirname(newPath)
        os.chdir(newPath)


def onRightClick(m, event):
    selectItem(event)
    m.tk_popup(event.x_root, event.y_root)

def pluginMenu(pg, event):
    selectItem(event)
    pg.tk_popup(event.x_root, event.y_root)


def search(searchEntry, event):
    fileNames = os.listdir()
    query = searchEntry.get()  # get query from text box
    query = query.lower()
    queryNames = []

    for name in fileNames:
        if name.lower().find(query) != -1:  # if query in name
            queryNames.append(name)
    ui.refresh(queryNames)


def del_file():
    if os.path.isfile(os.getcwd() + "/" + globals.selectedItem):
        try:
            os.remove(os.getcwd() + "/" + globals.selectedItem)
        except Exception as e:
            Messagebox.ok(
                title="Error",
                message="Unable to delete file\n" + str(e)
            )
        
    elif os.path.isdir(os.getcwd() + "/" + globals.selectedItem):
        # os.rmdir(os.getcwd() + "/" + selectedItem)
        try:
            shutil.rmtree(os.getcwd() + "/" + globals.selectedItem)
        except Exception as e:
            Messagebox.ok(
                title="Error",
                message="Unable to delete directory\n" + str(e)
            )




def copy():
    #global src, items
    if globals.items.focus() != "":  # if there is a focused item
        globals.src = os.getcwd() + "/" + globals.selectedItem


def paste():
    #global src
    dest = os.getcwd() + "/"
    if not os.path.isdir(globals.src) and globals.src != "":
        try:
            t1 = threading.Thread(
                target=shutil.copy2, args=(globals.src, dest)
            )  # use threads so gui does not hang on large file copy
            t2 = threading.Thread(target=ui.paste_popup, args=([t1]))
            t1.start()
            t2.start()
        except Exception as e:
            print(e)
            pass
    elif os.path.isdir(globals.src) and globals.src != "":
        try:
            new_dest_dir = os.path.join(dest, os.path.basename(globals.src))
            os.makedirs(new_dest_dir)
            t1 = threading.Thread(  # use threads so gui does not hang on large directory copy
                target=shutil.copytree,
                args=(globals.src, new_dest_dir, False, None, shutil.copy2, False, True),
            )
            t2 = threading.Thread(target=ui.paste_popup, args=([t1]))
            t1.start()
            t2.start()
        except Exception as e:
            print(e)
            pass

def backup_file():
    #global src, items
    if globals.items.focus() != "":  # if there is a focused item
        globals.src = os.getcwd() + "/" + globals.selectedItem

    #global src
    onedrive_path = os.getenv('OneDrive')
    dest = onedrive_path
    if not os.path.isdir(globals.src) and globals.src != "":
        try:
            t1 = threading.Thread(
                target=shutil.copy2, args=(globals.src, dest)
            )  # use threads so gui does not hang on large file copy
            t2 = threading.Thread(target=ui.paste_popup, args=([t1]))
            t1.start()
            t2.start()
        except Exception as e:
            print(e)
            pass
    elif os.path.isdir(globals.src) and globals.src != "":
        try:
            new_dest_dir = os.path.join(dest, os.path.basename(globals.src))
            os.makedirs(new_dest_dir)
            t1 = threading.Thread(  # use threads so gui does not hang on large directory copy
                target=shutil.copytree,
                args=(globals.src, new_dest_dir, False, None, shutil.copy2, False, True),
            )
            t2 = threading.Thread(target=ui.paste_popup, args=([t1]))
            t1.start()
            t2.start()
        except Exception as e:
            print(e)
            pass


    
def up_key(event):
    #global selectedItem, items
    iid = globals.items.focus()
    iid = globals.items.prev(iid)
    if iid:
        globals.items.selection_set(iid)
        globals.selectedItem = globals.items.item(iid)["values"][0]
        print(globals.selectedItem)
    else:
        pass


def down_key(event):
    #global selectedItem, items
    iid = globals.items.focus()
    iid = globals.items.next(iid)
    if iid:
        globals.items.selection_set(iid)
        globals.selectedItem = globals.items.item(iid)["values"][0]
        print(globals.selectedItem)
    else:
        pass


def sort_col(col, reverse):
    #global items
    l = [(globals.items.set(k, col), k) for k in globals.items.get_children("")]
    if col == "Name" or col == "Type":
        l.sort(reverse=reverse)
    elif col == "Date modified":
        l = sorted(l, key=sort_key_dates, reverse=reverse)

    # rearrange items in sorted positions
    for index, (val, k) in enumerate(l):
        globals.items.move(k, "", index)

    # reverse sort next time
    globals.items.heading(col, command=partial(sort_col, col, not reverse))


def sort_key_dates(item):
    return datetime.strptime(item[0], "%d-%m-%Y %H:%M")


def sort_key_size(item):
    num_size = item[0].split(" ")[0]
    if num_size != "":
        return int(num_size)
    else:
        return -1  # if it's a directory, give it negative size value, for sorting


def selectItem(event):
    iid = globals.items.identify_row(event.y)
    if iid:
        # Set the selected item
        globals.items.selection_set(iid)
        globals.selectedItem = globals.items.item(iid)["values"][0]
        globals.items.focus(iid)  # Give focus to iid
        
        # Remove custom styling from all items
        removeCustomStyling()
        
        # Apply light bootstyle or highlight class to the selected item
        applyHighlightStyle(iid)
    else:
        pass

def applyHighlightStyle(item_id):
    # Apply a custom bootstyle or class for the selected item
    # This should fit within the `ttkbootstrap` theming system
    # Note: Ensure this aligns with `ttkbootstrap` theming guidelines
    globals.items.item(item_id, tags=("highlight",))
    globals.items.tag_configure("highlight", background='', foreground='')  # Adjust according to bootstyle

    # Update Treeview appearance
    globals.items.update_idletasks()

def removeCustomStyling():
    # Remove highlight or custom styling from all items
    for item in globals.items.get_children():
        globals.items.item(item, tags=())
    globals.items.update_idletasks()


def cd_drive(drive, queryNames):
    #global fileNames, currDrive, cwdLabel
    globals.cwdLabel.config(text=" " + drive)
    globals.currDrive = drive
    globals.fileNames = os.listdir(globals.currDrive)
    os.chdir(globals.currDrive + "/")
    ui.refresh(queryNames)

def cd_driveprop(drive, queryNames):
    ui.open_properties(drive)


def write_theme(theme):
    with open(
        globals.file_path + "C:/Zero Software/ZeroFiles/res/theme.txt", "w"
    ) as f:  # closes file automatically
        f.write(theme)
    theme = str(theme).capitalize()



def change_scale(multiplier, s):
    scale = round(multiplier * tvdense)  # 28 is default
    s.configure("Treeview", rowheight=scale)


def change_font_popup(size):
    ui.warning_popup()
    change_font_size(size)


def change_font_size(size):
    with open(
        globals.file_path + "C:\\Zero Software\\ZeroFiles\\res\\font.txt", "w"
    ) as f:  # closes file automatically
        f.write(str(size))
