def load_theme_file():
    try:
        file_path = "C:\\Zero Software\\ZeroFiles\\res\\theme.txt"
        
        with open(file_path, "r") as file:
            content = file.read().strip()
        
        theme = str(content)
        return theme
    except Exception as e:
        print(f"Error loading file: {e}")
        return None

# Load the theme value
theme = load_theme_file()
if theme is not None:
    pass
else:
    theme = "yeti"  # Default value if loading fails

if theme == "litera":
    menuFGItem = "#929292"
elif theme == "yeti":
    menuFGItem = "#929292"
elif theme == "journal":
    menuFGItem = "#929292"
elif theme == "superhero":
    menuFGItem = "#b6b6b6"
elif theme == "cyborg":
    menuFGItem = "#b6b6b6"
elif theme == "morph":
    menuFGItem = "#9eaacb"
elif theme == "darkly":
    menuFGItem = "#b6b6b6"
elif theme == "vapor":
    menuFGItem = "#04d2b9"
elif theme == "cerculean":
    menuFGItem = "#76c5ef"
elif theme == "solar":
    menuFGItem = "#b6b6b6"
elif theme == "minty":
    menuFGItem = "#959595"
elif theme == "cosmo":
    menuFGItem = "#929292"
elif theme == "flatly":
    menuFGItem = "#929292"
elif theme == "lumen":
    menuFGItem = "#7b7b7b"
elif theme == "pulse":
    menuFGItem = "#7c7c7c"
elif theme == "sandstone":
    menuFGItem = "#62645b"
elif theme == "united":
    menuFGItem = "#676767"
elif theme == "simplex":
    menuFGItem = "#72767a"
