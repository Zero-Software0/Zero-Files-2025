import ttkbootstrap as ttk
import tkinter as tk

fileNames = []
file_path = ""  # path of main.py
lastDirectory = ""
selectedItem = ""  # focused item on Treeview
src = ""  # temp path for copying
theme = ""  # current theme
theme_mode = "" # light or dark
photo_ref = []  # keeps references of photos
currDrive = ""
available_drives = []
font_size = "12"  # default is 10
items: ttk.Treeview  # holds treeview items
cwdLabel: ttk.Entry
footer: ttk.Label

# UI icons
backIcon: list
frontIcon: list
copyIcon: list
cpuIcon: list
deleteIcon: list
driveIcon: list
fontIcon: list
appIcon: list
infoIcon: list
memoryIcon: list
networkIcon: list
pasteIcon: list
pieIcon: list
processIcon: list
reloadIcon: list
renameIcon: list
scaleIcon: list
themesIcon: list
exitIcon: list
gdriveIcon:list
configIcon:list
opacityIcon:list
winconfigIcon:list
windowIcon:list
userIcon:list
keybindIcon:list
tabIcon:list
onedrvIcon:list
dfIcon:list

# File Type Icons
folderIcon: list
fileIcon: list
docIcon:list
photoIcon:list
videoIcon:list
audioIcon:list
exeIcon:list
systemIcon:list
fontFileIcon:list
zipIcon:list


# available themes
# Dark
solarD = "solar"
superheroD = "superhero"
Darkly = "darkly"
CyborgD = "cyborg"
VaporD = "vapor"
# Light
literaL = "litera"
mintyL = "minty"
morphL = "morph"
yetiL = "yeti"
cerculeanL = "cerculean"
cosmoL = "cosmo"
flatlyL = "flatly"
lumenL = "lumen"
journalL = "journal"
pulseL = "pulse"
sandstoneL = "sandstone"
unitedL = "united"
simplexL = "simplex"