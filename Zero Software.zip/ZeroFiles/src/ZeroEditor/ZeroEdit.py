import subprocess
import os

def scan_file_with_windows_defender(file_path):
    """Scan a file with Windows Defender."""
    if not os.path.isfile(file_path):
        return f"{file_path} is not a valid file path."

    # Build the command to execute
    command = f'"{os.environ["ProgramFiles"]}\\Windows Defender\\mpcmdrun.exe" -scan -scantype 3 -file "{file_path}"'

    # Execute the command
    try:
        result = subprocess.run(command, capture_output=True, text=True, shell=True)
        return result.stdout  # This will return the output from the scan
    except Exception as e:
        return f"Error scanning file: {e}"

# Example usage
file_to_scan = r"C:\Users\THER3\Downloads\Firefox Installer.exe"
print(scan_file_with_windows_defender(file_to_scan))
