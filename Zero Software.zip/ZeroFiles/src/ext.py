# ext.py

import os

def get_file_type(filename):
    if os.path.isdir(filename):
        return "Directory"
    else:
        _, file_extension = os.path.splitext(filename)
        if file_extension.lower() in ['.txt', '.pdf', '.doc', '.docx']:
            return "Document"
        elif file_extension.lower() in ['.jpg', '.jpeg', '.png', '.gif', '.webp']:
            return "Image"
        elif file_extension.lower() in ['.mp3', '.wav', '.flac', '.mid']:
            return "Audio"
        elif file_extension.lower() in ['.mp4', '.avi', '.mkv']:
            return "Video"
        elif file_extension.lower() in ['.exe', '.com', '.scr']:
            return "Application"
        elif file_extension.lower() in ['.py', '.pyw', '.pyc']:
            return "Python"
        elif file_extension.lower() in ['.ini', '.sys', '.bin', '.tmp', 'log', '.dll']:
            return "System"
        elif file_extension.lower() in ['.ttf', '.otf']:
            return "Font"
        elif file_extension.lower() in ['.zip', '.7z']:
            return "ZIP Archive"
        elif file_extension.lower() in ['.cpl']:
            return "Control Panel"
        else:
            formatted_extension = file_extension.upper() + " File"
            return formatted_extension
