import ui
import os
import util
import psutil
import globals
import time
import func

import ttkbootstrap as ttk
import tkinter as tk

from PIL import Image, ImageTk
from ttkbootstrap.dialogs.dialogs import Messagebox
from ttkbootstrap.dialogs.dialogs import Querybox
from ttkbootstrap.tooltip import ToolTip
from ttkbootstrap.constants import *

def load_dtformat_file():
    try:
        file_path = r"C:\Zero Software\ZeroFiles\res\config\view\dateformat.txt"
        
        with open(file_path, "r") as file:
            content = file.read().strip()
        dateFormat = str(content)
        return dateFormat
    except Exception as e:
        print(f"Error loading file: {e}")
        return None

# Load the date format
dateFormat = load_dtformat_file()
if dateFormat is not None:
    pass
else:
    dateFormat = "%d/%m/%Y %H:%M"  # Default value if loading fails

if dateFormat == "%d/%m/%Y %H:%M":
    dateFormat = "DD/MM/YYYY"
elif dateFormat == "%m/%d/%Y %H:%M":
    dateFormat = "MM/DD/YYYY"
elif dateFormat == "%Y/%m/%d %H:%M":
    dateFormat = "YYYY/MM/DD"

def load_typeface_file():
    try:
        file_path = r"C:\Zero Software\ZeroFiles\res\typeface.txt"
        
        with open(file_path, "r") as file:
            content = file.read().strip()
        
        typeFaceCn = str(content)
        return typeFaceCn
    except Exception as e:
        print(f"Error loading file: {e}")
        return None

# Load the typeface
typeFaceCn = load_typeface_file()
if typeFaceCn is not None:
    pass
else:
    
    typeFaceCn = "Inter"  # Default value if loading fails

def load_fontsize_file():
    try:
        file_path = r"C:\Zero Software\ZeroFiles\res\font.txt"
        
        with open(file_path, "r") as file:
            content = file.read().strip()
        
        fontSizeDt = str(content)
        return fontSizeDt
    except Exception as e:
        print(f"Error loading file: {e}")
        return None

# Load the fontSizeDt
fontSizeDt = load_fontsize_file()
if fontSizeDt is not None:
    pass
else:
    fontSizeDt = "12"  # Default value if loading fails

def load_theme_file():
    try:
        file_path = r"C:\Zero Software\ZeroFiles\res\theme.txt"
        
        with open(file_path, "r") as file:
            content = file.read().strip()
        
        theme = str(content)
        return theme
    except Exception as e:
        print(f"Error loading file: {e}")
        return None

# Load the theme
theme = load_theme_file()
if theme is not None:
    pass
else:
    theme = "Litera"  # Default value if loading fails

# typeface select
def tfsize():
    tfstyle = Messagebox.show_question(
        title="Font Size",
        message="FONT SIZE\nSelect a font size to be used in Zero Files",
        buttons=['18', '14', '12', '10', '8'],
        alert=False,
    )

    if tfstyle == '18':
        ui.change_font_popup(18)
    elif tfstyle == '14':
        ui.change_font_popup(14)
    elif tfstyle == '12':
        ui.change_font_popup(12)
    elif tfstyle == '10':
        ui.change_font_popup(10)
    elif tfstyle == '8':
        ui.change_font_popup(8)

# typeface menu
def tf_menu():
    tftoggle = Messagebox.show_question(
        title="Font Style",
        message="FONT\nThis option allows you to customise the font in Zero Files\nCurrent Font: " + typeFaceCn + " (size " + fontSizeDt + ")",
        buttons=['Typeface', 'Size', 'Cancel'],
        alert=False,
    )

    if tftoggle == 'Typeface':
        util.font_warning()
    elif tftoggle == 'Size':
        tfsize()
    elif tftoggle == 'Cancel':
        return



# date select select
def df_select():
    dfmode = Messagebox.show_question(
        title="Date Format",
        message="DATE FORMAT\nSelect a date format.",
        buttons=['DD/MM/YY', 'MM/DD/YY', 'YY/MM/DD'],
        alert=False,
    )

    if dfmode == 'DD/MM/YY':
        util.dfDMY()
    elif dfmode == 'MM/DD/YY':
        util.dfMDY()
    elif dfmode == 'YY/MM/DD':
        util.dfYMD()

# dateformat menu
def df_menu():
    dftoggle = Messagebox.show_question(
        title="Date Format",
        message="DATE FORMAT\nYou can select a different date format for the date modified column\nCurrent Format: " + dateFormat,
        buttons=['Configure', 'Cancel'],
        alert=False,
    )

    if dftoggle == 'Configure':
        df_select()
    elif dftoggle == 'Cancel':
        return

# tablet mode menu
def tbm_menu():
    tbtoggle = Messagebox.show_question(
        title="Tablet Mode",
        message="TABLET MODE\nTablet Mode increases the size of items making them easier to tap. ",
        buttons=['Enable', 'Disable', 'Cancel'],
        alert=False,
    )

    if tbtoggle == 'Enable':
        util.tabon()
    elif tbtoggle == 'Disable':
        util.taboff()
    elif tbtoggle == 'Cancel':
        return

# transparency select
def tp_select():
    tpmode = Messagebox.show_question(
        title="Set Opacity",
        message="SET OPACITY\nHigh - High Translucency\nLow - Low Translucency",
        buttons=['High', 'Low'],
        alert=False,
    )

    if tpmode == 'High':
        util.set092tp()
    elif tpmode == 'Low':
        util.set095tp()



# transparency mode menu
def tp_menu():
    tptoggle = Messagebox.show_question(
        title="Opacity",
        message="OPACITY\nOpacity allows you to set the translucency of the window, for an aero effect.",
        buttons=['Enable', 'Disable', 'Cancel'],
        alert=False,
    )

    if tptoggle == 'Enable':
        tp_select()
    elif tptoggle == 'Disable':
        util.set1tp()
    elif tptoggle == 'Cancel':
        return

def themeConfig():
    try:
        os.startfile("C:\\Zero Software\\ZeroFiles\\src\\theme_library.pyw")
        print("Started")
    except Exception as e:
        print(f"Error: {e}")

def toolbar():
    try:
        os.startfile("C:\\Zero Software\\ZeroFiles\\src\\toolbars.pyw")
        print("Started")
    except Exception as e:
        print(f"Error: {e}")
    
import os

def accentCol():

    try:
        os.startfile("C:\\Zero Software\\ZeroFiles\\src\\accentCol.pyw")
    except FileNotFoundError:
        Messagebox.show_error(
            title="File Not Found",
            message="The file accentCol.pyw was not found. Please check the file path and try again.",
            alert=True
        )

def quickaccess():
    try:
        os.startfile("C:\\Zero Software\\ZeroFiles\\src\\quickaccess.pyw")
        print("Started")
    except Exception as e:
        print(f"Error: {e}")

def themeConfigFromApp():
    try:
        os.startfile("C:\\Zero Software\\ZeroFiles\\src\\settings_menu.pyw")
        os.startfile("C:\\Zero Software\\ZeroFiles\\src\\theme_library.pyw")
        
        quit()
        print("Started")
    except Exception as e:
        print(f"Error: {e}")
# terminal select
def tr_select():
    trmode = Messagebox.show_question(
        title="Set Terminal",
        message="SET TERMINAL\nSelect one of the two main windows terminals to use.",
        buttons=['CMD', 'Powershell'],
        alert=False,
    )

    if trmode == 'CMD':
        util.setCMD()
    elif trmode == 'Powershell':
        util.setPS()

# transparency mode menu
def terminal_menu():
    terminalmenu = Messagebox.show_question(
        title="Terminal",
        message="TERMINAL\nSet the default terminal that Zero Files uses",
        buttons=['Set Terminal', 'Cancel'],
        alert=False,
    )

    if terminalmenu == 'Set Terminal':
        tr_select()
    elif terminalmenu == 'Cancel':
        return
    

# su select
def select_su():
    trmode = Messagebox.show_question(
        title="Set Size Units",
        message="SET SIZE UNITS\nKB:Used for smaller files, such as .txt or .jpeg\nMB:Default Unit used for average sized files.",
        buttons=['Kilobytes', 'Megabytes'],
        alert=False,
    )

    if trmode == 'Kilobytes':
        util.setKBFileSize()
    elif trmode == 'Megabytes':
        util.setMBFileSize()

# transparency mode menu
def size_units():
    terminalmenu = Messagebox.show_question(
        title="Size Units",
        message="SIZE UNITS\nSelect whether file sizes are shown in MB or KB.",
        buttons=['Set Units', 'Cancel'],
        alert=False,
    )

    if terminalmenu == 'Set Units':
        select_su()
    elif terminalmenu == 'Cancel':
        return
    
# Dock Settings
def dock_pos():
    dockpos = Messagebox.show_question(
        title="Dock Position",
        message="POSITION\nTop: Places dock at the top. Good for those used to Windows Explorer.\nBottom: Default, places dock at the bottom.",
        buttons=['Top', 'Bottom'],
        alert=False,
    )

    if dockpos == 'Top':
        util.setDockTop()
    elif dockpos == 'Bottom':
        util.setDockBottom()