def load_theme_file():
    try:
        file_path = "C:\\Zero Software\\ZeroFiles\\res\\theme.txt"
        print(f"Attempting to load file from: {file_path}")
        
        with open(file_path, "r") as file:
            content = file.read().strip()
        
        print("File loaded successfully.")
        theme = str(content)
        return theme
    except Exception as e:
        print(f"Error loading file: {e}")
        return None

# Load the theme value
theme = load_theme_file()
if theme is not None:
    print(f"File content loaded into 'theme' variable: {theme}")
else:
    print("Failed to load file content. Using default theme value.")
    theme = "yeti"  # Default value if loading fails

def load_accent():
    try:
        file_path = r"C:\Zero Software\ZeroFiles\res\accent.txt"
        
        with open(file_path, "r") as file:
            content = file.read().strip()
        
        fontSizeDt = str(content)
        return fontSizeDt
    except Exception as e:
        print(f"Error loading file: {e}")
        return None

# Load the accent
accent = load_accent()
if accent is not None:
    pass
else:
    accent = "primary"  # Default value if loading fails

if accent == "none": 
    if theme == "yeti" or theme == "flatly" or theme == "morph" or theme == "litera" or theme == "cerculean" or theme == "journal":
        bootstyle = "light"
else:
    if theme == "yeti" or theme == "flatly" or theme == "morph" or theme == "litera" or theme == "cerculean" or theme == "journal":
        bootstyle = "light"
    else:
        bootstyle = accent

def load_fontsize_file():
    try:
        file_path = r"C:\Zero Software\ZeroFiles\res\font.txt"
        
        with open(file_path, "r") as file:
            content = file.read().strip()
        
        fontSizeDt = str(content)
        return fontSizeDt
    except Exception as e:
        print(f"Error loading file: {e}")
        return None

# Load the fontSizeDt
fontSizeDt = load_fontsize_file()
if fontSizeDt is not None:
    pass
else:
    fontSizeDt = "12"  # Default value if loading fails


def load_fontstyle_file():
    try:
        file_path = r"C:\Zero Software\ZeroFiles\res\typeface.txt"
        print(f"Attempting to load file from: {file_path}")
        
        with open(file_path, "r") as file:
            content = file.read().strip()
        
        print("File loaded successfully.")
        fontstyle = str(content)
        return fontstyle
    except Exception as e:
        print(f"Error loading file: {e}")
        return None

fontstyle = load_fontstyle_file()
if fontstyle is not None:
    print(f"File content loaded into 'fontstyle' variable: {fontstyle}")
else:
    print("Failed to load file content. Using default fontstyle value.")
    fontstyle = "Inter"  # Default value if loading fails